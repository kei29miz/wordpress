<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$latest = new WP_Query( array( 'posts_per_page' => 5, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
br_topbar( 'Page not found', 'page' );
?>
<div class="stack"><section class="card empty"><h2>This page wandered off</h2><p>The link may be old or mistyped. Try one of these instead, or <a href="<?php echo esc_url( br_page_url( 'explore' ) ); ?>">search the blog</a>.</p>
<p><a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">Go home</a> <a class="btn btn-outline" href="#" data-random>Surprise me</a></p></section>
<?php if ( $latest->have_posts() ) : ?>
<section class="card feed"><div class="ex-head"><h2>Latest</h2></div><?php
	while ( $latest->have_posts() ) { $latest->the_post(); get_template_part( 'template-parts/card' ); }
	wp_reset_postdata();
?></section>
<?php endif; ?></div>
<?php get_footer(); ?>
