Bee Randomly — WordPress theme

1. Appearance > Themes > Add New > Upload Theme > choose beerandomly-theme.zip > Activate.
2. Tools > Import > WordPress (install the importer if asked) > upload beerandomly-content.xml.
   This adds your 7 posts, the "Thoughts" category, tags, and the About, Privacy, Blog, Thoughts and Explore pages.
3. Settings > General: set Site Title to "Bee Randomly" and the Tagline.
4. Settings > Permalinks: choose Custom Structure  /posts/%postname%/  to keep your old /posts/... URLs.
5. Appearance > Customize > Bee Randomly profile: edit the short bio and location.

Thoughts are normal posts in the "thoughts" category. Cover images: set a Featured Image, or the theme falls back to the bundled covers.


2.0.0: new social-feed design (assets/css/modern.css). Bee logo and wordmark unchanged.
