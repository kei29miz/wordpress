<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

if ( is_tag() ) {
	$heading = '#' . single_tag_title( '', false );
	$icon    = 'blog';
} elseif ( is_category() ) {
	$heading = single_cat_title( '', false );
	$icon    = is_category( 'thoughts' ) ? 'thoughts' : 'blog';
} elseif ( is_home() || is_front_page() ) {
	$heading = 'Latest';
	$icon    = 'blog';
} else {
	$heading = wp_strip_all_tags( get_the_archive_title() );
	$icon    = 'blog';
}
global $wp_query;
$n   = (int) $wp_query->found_posts;
$sub = sprintf( _n( '%d entry', '%d entries', $n, 'beerandomly' ), $n );
br_topbar( $heading, 'page' );
?>
<div class="stack"><?php
get_template_part( 'template-parts/page-head', null, array(
	'cv'    => is_category( 'thoughts' ) ? 'cv-lavender' : 'cv-honey',
	'icon'  => $icon,
	'title' => $heading,
	'sub'   => $sub,
) );
if ( have_posts() ) :
	if ( is_category( 'thoughts' ) ) :
		?><div class="tgrid"><?php
		while ( have_posts() ) { the_post(); get_template_part( 'template-parts/tcard' ); }
		?></div><?php
	else :
		?><section class="card feed"><?php
		while ( have_posts() ) { the_post(); get_template_part( 'template-parts/card' ); }
		?></section><?php
	endif;
	br_pagination();
else :
	?><section class="card empty"><h2>No entries yet</h2><p>Nothing has been filed under this topic.</p><p><a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">Go home</a></p></section><?php
endif;
?></div>
<?php get_footer(); ?>
