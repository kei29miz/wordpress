<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
$br_active = br_active();
$br_bottom = array(
	'home'     => array( home_url( '/' ), 'Home' ),
	'explore'  => array( br_page_url( 'explore' ), 'Explore' ),
	'thoughts' => array( br_page_url( 'thoughts' ), 'Thoughts' ),
	'blog'     => array( br_page_url( 'blog' ), 'Blog' ),
	'about'    => array( br_page_url( 'about' ), 'About' ),
);
?>
</main>
<?php get_sidebar(); ?>
</div>
<nav class="bottombar" aria-label="Main"><?php
foreach ( $br_bottom as $key => $item ) {
	printf(
		'<a href="%s"%s>%s<span>%s</span></a>',
		esc_url( $item[0] ),
		$br_active === $key ? ' aria-current="page"' : '',
		br_icon( $key ), // phpcs:ignore
		esc_html( $item[1] )
	);
}
?></nav>
<div class="toast" id="toast" role="status"></div>
<?php wp_footer(); ?>
</body>
</html>
