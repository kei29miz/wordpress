<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();

$ex     = br_exclude_thoughts();
$base   = array( 'posts_per_page' => 1, 'category__not_in' => $ex, 'ignore_sticky_posts' => true, 'no_found_rows' => true );
$sticky = get_option( 'sticky_posts' );
$feat   = null;
if ( $sticky ) {
	$try = new WP_Query( array_merge( $base, array( 'post__in' => $sticky ) ) );
	if ( $try->have_posts() ) { $feat = $try; }
}
if ( ! $feat ) { $feat = new WP_Query( $base ); }
$feat_id = $feat->have_posts() ? $feat->posts[0]->ID : 0;

$feed = new WP_Query( array(
	'posts_per_page'      => 12,
	'post__not_in'        => $feat_id ? array( $feat_id ) : array(),
	'ignore_sticky_posts' => true,
	'no_found_rows'       => true,
) );

br_topbar( br_name(), 'page' );
?>
<div class="stack"><section class="card mini"><div class="cv cv-honey"><div style="height:64px"></div></div><div class="mini-body"><?php echo br_avatar(); // phpcs:ignore ?><div class="mini-id"><div class="nm"><?php echo esc_html( br_name() ); ?></div><div class="sub">🐝 <?php echo esc_html( br_tagline() ); ?></div></div><a class="btn btn-outline" href="<?php echo esc_url( br_page_url( 'about' ) ); ?>">About me</a></div><p><?php echo esc_html( br_bio() ); ?></p></section>
<?php
while ( $feat->have_posts() ) :
	$feat->the_post();
	$cover = br_cover();
	$tags  = get_the_tags();
	?>
<article class="card bcard" data-open="<?php echo esc_url( get_permalink() ); ?>" tabindex="0"><?php if ( $cover ) : ?><div class="bband" style="height:220px"><img src="<?php echo esc_url( $cover['url'] ); ?>" alt="<?php echo esc_attr( $cover['alt'] ); ?>" width="<?php echo (int) $cover['w']; ?>" height="<?php echo (int) $cover['h']; ?>"<?php echo $cover['pos'] ? ' style="object-position:' . esc_attr( $cover['pos'] ) . '"' : ''; ?> fetchpriority="high"></div><?php else : ?><div class="bband cv <?php echo esc_attr( br_cv_class() ); ?>"></div><?php endif; ?><div class="bbody feature"><h2 class="sr-only">Featured story</h2><div class="kicker" aria-hidden="true"><span class="dot"></span>Featured story</div><div class="bmeta"><span><time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></time></span><span><?php echo esc_html( br_read_label() ); ?></span></div><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p class="bex"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p><?php if ( $tags ) : ?><div class="tags"><?php foreach ( array_slice( $tags, 0, 3 ) as $t ) : ?><a class="tag" href="<?php echo esc_url( get_tag_link( $t ) ); ?>">#<?php echo esc_html( $t->name ); ?></a><?php endforeach; ?></div><?php endif; ?><div class="actions"><?php echo br_share_btn( get_permalink(), wp_strip_all_tags( get_the_title() ) ); // phpcs:ignore ?></div></div></article>
	<?php
endwhile;
wp_reset_postdata();
?>
<section class="card feed"><h2 class="sr-only">Latest posts and thoughts</h2><div class="tabs" role="tablist"><button class="tab" role="tab" data-ftab="all" aria-selected="true">Latest</button><button class="tab" role="tab" data-ftab="post" aria-selected="false">Articles</button><button class="tab" role="tab" data-ftab="thought" aria-selected="false">Thoughts</button></div><div id="feed"><?php
if ( $feed->have_posts() ) {
	while ( $feed->have_posts() ) {
		$feed->the_post();
		get_template_part( 'template-parts/card' );
	}
	wp_reset_postdata();
} elseif ( ! $feat_id ) {
	echo '<div class="empty"><h2>Nothing here yet</h2><p>Publish your first post and it will show up here.</p></div>';
}
?></div></section></div>
<?php get_footer(); ?>
