<?php
/**
 * Bee Randomly theme functions.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'BR_VERSION', '2.0.1' );

/* ---------- Setup ---------- */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'customize-selective-refresh-widgets' );
} );

add_filter( 'excerpt_length', function () { return 30; } );
add_filter( 'excerpt_more', function () { return '…'; } );
add_filter( 'comments_open', '__return_false', 20 );
add_filter( 'pings_open', '__return_false', 20 );

/* On activation: Thoughts category + friendly permalinks (only if still on "Plain"). */
add_action( 'after_switch_theme', function () {
	if ( ! term_exists( 'thoughts', 'category' ) ) {
		wp_insert_term( 'Thoughts', 'category', array( 'slug' => 'thoughts' ) );
	}
	global $wp_rewrite;
	if ( ! get_option( 'permalink_structure' ) ) {
		$wp_rewrite->set_permalink_structure( '/posts/%postname%/' );
	}
	$wp_rewrite->flush_rules( false );
} );

/* ---------- Assets ---------- */
/* A classic theme ships its own full stylesheet; WordPress's block/global-style CSS only adds rules that can fight it. */
add_action( 'wp_enqueue_scripts', function () {
	wp_dequeue_style( 'wp-block-library' );
	wp_dequeue_style( 'wp-block-library-theme' );
	wp_dequeue_style( 'classic-theme-styles' );
	wp_dequeue_style( 'global-styles' );
}, 100 );

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'br-fonts',
		'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400..800&family=Caveat:wght@600;700&family=Literata:ital,opsz,wght@0,7..72,400..600;1,7..72,400..500&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'br-style', get_stylesheet_uri(), array( 'br-fonts' ), BR_VERSION );
	wp_enqueue_style( 'br-wp', get_theme_file_uri( 'assets/css/wp-extra.css' ), array( 'br-style' ), BR_VERSION );
	wp_enqueue_style( 'br-modern', get_theme_file_uri( 'assets/css/modern.css' ), array( 'br-wp' ), BR_VERSION );
	wp_enqueue_script( 'br-site', get_theme_file_uri( 'assets/js/site.js' ), array(), BR_VERSION, true );

	$pool = array();
	$q    = new WP_Query( array(
		'post_type'      => 'post',
		'posts_per_page' => 200,
		'no_found_rows'  => true,
		'fields'         => 'ids',
	) );
	foreach ( $q->posts as $pid ) {
		$pool[] = array( 'u' => get_permalink( $pid ) );
	}
	wp_reset_postdata();
	wp_add_inline_script(
		'br-site',
		'window.BR_POSTS=' . wp_json_encode( $pool ) . ';window.BR_EXPLORE=' . wp_json_encode( br_page_url( 'explore' ) ) . ';',
		'before'
	);
} );

add_action( 'wp_head', function () {
	echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
	echo '<script>try{var t=localStorage.getItem("br-theme");if(t)document.documentElement.dataset.theme=t}catch(e){}</script>' . "\n";
}, 1 );

/* ---------- Customizer ---------- */
add_action( 'customize_register', function ( $wp_customize ) {
	$wp_customize->add_section( 'br_profile', array(
		'title'    => __( 'Bee Randomly profile', 'beerandomly' ),
		'priority' => 30,
	) );
	$wp_customize->add_setting( 'br_bio', array(
		'default'           => "A little unfiltered. A little existential. Entirely human. For thoughts that don't fit in a tweet, feelings that don't fit in a caption, and stories that deserve more than a scroll.",
		'sanitize_callback' => 'sanitize_textarea_field',
	) );
	$wp_customize->add_control( 'br_bio', array(
		'section' => 'br_profile',
		'label'   => __( 'Short bio (home card and author box)', 'beerandomly' ),
		'type'    => 'textarea',
	) );
	$wp_customize->add_setting( 'br_location', array(
		'default'           => 'Quezon City',
		'sanitize_callback' => 'sanitize_text_field',
	) );
	$wp_customize->add_control( 'br_location', array(
		'section' => 'br_profile',
		'label'   => __( 'Location (About page byline)', 'beerandomly' ),
		'type'    => 'text',
	) );
} );

/* ---------- Helpers ---------- */
function br_name() {
	return get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : 'Bee Randomly';
}

function br_tagline() {
	$t = get_bloginfo( 'description' );
	return $t ? $t : 'Thinking out loud, one random thought at a time';
}

function br_bio() {
	return get_theme_mod( 'br_bio', "A little unfiltered. A little existential. Entirely human. For thoughts that don't fit in a tweet, feelings that don't fit in a caption, and stories that deserve more than a scroll." );
}

function br_page_url( $slug ) {
	$p = get_page_by_path( $slug );
	return $p ? get_permalink( $p ) : home_url( '/' . $slug . '/' );
}

function br_thoughts_term_id() {
	$t = get_category_by_slug( 'thoughts' );
	return $t ? (int) $t->term_id : 0;
}

function br_exclude_thoughts() {
	$id = br_thoughts_term_id();
	return $id ? array( $id ) : array();
}

function br_is_thought( $post = null ) {
	return has_category( 'thoughts', $post );
}

function br_text( $post = null ) {
	$post = get_post( $post );
	return trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( strip_shortcodes( $post->post_content ) ) ) );
}

function br_words( $post = null ) {
	$t = br_text( $post );
	return $t === '' ? 0 : count( preg_split( '/\s+/u', $t, -1, PREG_SPLIT_NO_EMPTY ) );
}

function br_read_label( $post = null ) {
	if ( br_is_thought( $post ) ) {
		return 'Quick read';
	}
	return max( 1, (int) round( br_words( $post ) / 225 ) ) . ' min read';
}

function br_thought_text( $post = null ) {
	$t = br_text( $post );
	return $t !== '' ? $t : wp_strip_all_tags( get_the_title( $post ) );
}

function br_short( $text, $n = 50 ) {
	return mb_strlen( $text ) > $n ? rtrim( mb_substr( $text, 0, $n ) ) . '…' : $text;
}

function br_icon( $name ) {
	static $i = array(
		'home'     => '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>',
		'explore'  => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
		'thoughts' => '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V16h5.2v-.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"/>',
		'blog'     => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
		'about'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
		'random'   => '<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
		'moon'     => '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
		'share'    => '<path d="M12 3v13M7 8l5-5 5 5"/><path d="M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/>',
		'back'     => '<path d="M19 12H5M12 19l-7-7 7-7"/>',
	);
	return '<svg class="i" viewBox="0 0 24 24" aria-hidden="true">' . $i[ $name ] . '</svg>';
}

function br_avatar( $class = 'avatar' ) {
	return '<div class="' . esc_attr( $class ) . '"><svg viewBox="-26 -22 46 36" aria-hidden="true"><use href="#bee" transform="rotate(-12)"/></svg></div>';
}

function br_share_btn( $url, $title ) {
	return '<button type="button" class="act" data-share="' . esc_url( $url ) . '" data-title="' . esc_attr( $title ) . '" aria-label="Share">' . br_icon( 'share' ) . '</button>';
}

/* Which nav item is active? */
function br_active() {
	if ( is_front_page() ) { return 'home'; }
	if ( is_search() || is_page_template( 'template-explore.php' ) ) { return 'explore'; }
	if ( is_page_template( 'template-thoughts.php' ) || is_category( 'thoughts' ) || ( is_single() && br_is_thought() ) ) { return 'thoughts'; }
	if ( is_page_template( 'template-blog.php' ) || is_single() || is_tag() || is_archive() || is_home() ) { return 'blog'; }
	if ( is_page( 'about' ) ) { return 'about'; }
	return '';
}

add_filter( 'body_class', function ( $c ) {
	if ( is_single() || ( is_page() && ! get_page_template_slug() ) ) {
		$c[] = 'reading';
	}
	return $c;
} );

/* ---------- Covers ---------- */
function br_cover_map() {
	static $map = null;
	if ( null === $map ) {
		$file = get_theme_file_path( 'covermap.json' );
		$map  = file_exists( $file ) ? json_decode( file_get_contents( $file ), true ) : array();
		if ( ! is_array( $map ) ) { $map = array(); }
	}
	return $map;
}

/** Returns array(url, alt, w, h, pos, credit) or null. */
function br_cover( $post = null ) {
	$post = get_post( $post );
	if ( has_post_thumbnail( $post ) ) {
		$tid = get_post_thumbnail_id( $post );
		$src = wp_get_attachment_image_src( $tid, 'large' );
		if ( $src ) {
			return array(
				'url'    => $src[0],
				'alt'    => (string) get_post_meta( $tid, '_wp_attachment_image_alt', true ),
				'w'      => $src[1],
				'h'      => $src[2],
				'pos'    => '',
				'credit' => '',
			);
		}
	}
	$map = br_cover_map();
	$m   = isset( $map[ $post->post_name ] ) ? $map[ $post->post_name ] : array();
	if ( ! empty( $m['file'] ) && file_exists( get_theme_file_path( 'assets/covers/' . $m['file'] . '.webp' ) ) ) {
		return array(
			'url'    => get_theme_file_uri( 'assets/covers/' . $m['file'] . '.webp' ),
			'alt'    => isset( $m['alt'] ) ? $m['alt'] : '',
			'w'      => isset( $m['w'] ) ? $m['w'] : 1080,
			'h'      => isset( $m['h'] ) ? $m['h'] : 720,
			'pos'    => isset( $m['pos'] ) ? $m['pos'] : '',
			'credit' => isset( $m['credit'] ) ? $m['credit'] : '',
		);
	}
	return null;
}

function br_cv_class( $post = null ) {
	$post = get_post( $post );
	$map  = br_cover_map();
	if ( ! empty( $map[ $post->post_name ]['cv'] ) ) {
		return $map[ $post->post_name ]['cv'];
	}
	$all = array( 'cv-honey', 'cv-lavender', 'cv-meadow', 'cv-dusk', 'cv-night' );
	return $all[ $post->ID % count( $all ) ];
}

function br_tc_class( $post = null ) {
	$post = get_post( $post );
	$map  = br_cover_map();
	if ( ! empty( $map[ $post->post_name ]['tc'] ) ) {
		return $map[ $post->post_name ]['tc'];
	}
	$all = array( 'tc-lavender', 'tc-honey', 'tc-meadow', 'tc-rose' );
	return $all[ $post->ID % count( $all ) ];
}

function br_og_image( $post = null ) {
	$post = get_post( $post );
	if ( has_post_thumbnail( $post ) ) {
		return get_the_post_thumbnail_url( $post, 'large' );
	}
	$map = br_cover_map();
	if ( ! empty( $map[ $post->post_name ]['og'] ) && file_exists( get_theme_file_path( 'assets/og/' . $map[ $post->post_name ]['og'] ) ) ) {
		return get_theme_file_uri( 'assets/og/' . $map[ $post->post_name ]['og'] );
	}
	return get_theme_file_uri( 'assets/og/og-default.png' );
}

/* ---------- Top bar ---------- */
function br_topbar( $title, $mode = 'page' ) {
	echo '<div class="topbar">';
	if ( 'back' === $mode ) {
		echo '<a class="icon-btn" href="' . esc_url( home_url( '/' ) ) . '" data-back aria-label="Back">' . br_icon( 'back' ) . '</a>';
		echo '<p class="topbar-title">' . esc_html( $title ) . '</p>';
	} elseif ( 'backh1' === $mode ) {
		echo '<a class="icon-btn" href="' . esc_url( home_url( '/' ) ) . '" data-back aria-label="Back">' . br_icon( 'back' ) . '</a>';
		echo '<h1>' . esc_html( $title ) . '</h1>';
	} elseif ( 'title' === $mode ) {
		echo '<a class="mob-brand" href="' . esc_url( home_url( '/' ) ) . '" aria-label="Home"><svg viewBox="0 0 64 64" aria-hidden="true"><use href="#logo"/></svg></a>';
		echo '<p class="topbar-title">' . esc_html( $title ) . '</p>';
	} else {
		echo '<a class="mob-brand" href="' . esc_url( home_url( '/' ) ) . '" aria-label="Home"><svg viewBox="0 0 64 64" aria-hidden="true"><use href="#logo"/></svg></a>';
		echo '<h1>' . esc_html( $title ) . '</h1>';
	}
	echo '<span class="grow"></span><button class="icon-btn mob-only" data-theme-toggle aria-label="Switch theme">' . br_icon( 'moon' ) . '</button></div>' . "\n";
}

/* ---------- Pagination ---------- */
function br_pagination() {
	global $wp_query;
	if ( $wp_query->max_num_pages < 2 ) { return; }
	$newer = get_previous_posts_page_link();
	$older = get_next_posts_page_link();
	echo '<nav class="pn" aria-label="More posts">';
	if ( $newer && get_query_var( 'paged' ) > 1 ) {
		echo '<a href="' . esc_url( $newer ) . '"><small>Newer</small><b>Newer posts</b></a>';
	}
	if ( $older ) {
		echo '<a href="' . esc_url( $older ) . '"><small>Older</small><b>Older posts</b></a>';
	}
	echo '</nav>';
}

/* ---------- SEO (skipped when an SEO plugin is active) ---------- */
function br_has_seo_plugin() {
	return defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'THE_SEO_FRAMEWORK_VERSION' );
}

add_action( 'wp_head', function () {
	if ( ! has_site_icon() ) {
		$u = get_theme_file_uri( 'assets/og/' );
		echo '<link rel="icon" href="' . esc_url( $u . 'favicon-192.png' ) . '" sizes="192x192">' . "\n";
		echo '<link rel="icon" href="' . esc_url( $u . 'favicon-96.png' ) . '" sizes="96x96">' . "\n";
		echo '<link rel="icon" href="' . esc_url( $u . 'favicon-48.png' ) . '" sizes="48x48">' . "\n";
		echo '<link rel="icon" href="' . esc_url( $u . 'favicon-32.png' ) . '" sizes="32x32">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( $u . 'apple-touch-icon.png' ) . '">' . "\n";
	}
	if ( br_has_seo_plugin() ) { return; }

	$site = br_name();
	$desc = '';
	$url  = '';
	$type = 'website';
	$img  = get_theme_file_uri( 'assets/og/og-default.png' );
	$title = wp_get_document_title();

	if ( is_singular() ) {
		$p    = get_queried_object();
		$url  = get_permalink( $p );
		$desc = has_excerpt( $p ) ? wp_strip_all_tags( get_the_excerpt( $p ) ) : br_short( br_text( $p ), 160 );
		$img  = br_og_image( $p );
		$type = is_page() ? 'website' : 'article';
	} elseif ( is_front_page() ) {
		$url  = home_url( '/' );
		$desc = br_tagline();
		echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
	}
	if ( ! $url ) { return; }

	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	echo '<meta property="og:site_name" content="' . esc_attr( $site ) . '">' . "\n";
	echo '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	if ( $desc ) {
		echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta name="twitter:image" content="' . esc_url( $img ) . '">' . "\n";

	$graph = array( '@context' => 'https://schema.org' );
	if ( is_singular( 'post' ) ) {
		$p = get_queried_object();
		$graph += array(
			'@type'         => 'BlogPosting',
			'headline'      => wp_strip_all_tags( get_the_title( $p ) ),
			'description'   => $desc,
			'url'           => $url,
			'image'         => $img,
			'datePublished' => get_post_time( 'c', true, $p ),
			'dateModified'  => get_post_modified_time( 'c', true, $p ),
			'author'        => array( '@type' => 'Person', 'name' => $site, 'url' => br_page_url( 'about' ) ),
			'publisher'     => array( '@type' => 'Organization', 'name' => $site ),
			'mainEntityOfPage' => $url,
			'inLanguage'    => get_bloginfo( 'language' ),
		);
	} elseif ( is_front_page() ) {
		$graph += array(
			'@type'       => 'WebSite',
			'name'        => $site,
			'url'         => $url,
			'description' => $desc,
			'inLanguage'  => get_bloginfo( 'language' ),
		);
	} else {
		return;
	}
	echo '<script type="application/ld+json">' . wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}, 5 );


/* ---------- Hide WordPress's untouched default "Hello world!" sample post ---------- */
function br_sample_post_id() {
	static $id = null;
	if ( null === $id ) {
		$id = 0;
		$p  = get_page_by_path( 'hello-world', OBJECT, 'post' );
		if ( $p && 0 === strpos( trim( wp_strip_all_tags( $p->post_content ) ), 'Welcome to WordPress' ) ) {
			$id = (int) $p->ID;
		}
	}
	return $id;
}

add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || $q->is_singular() ) { return; }
	$pt = $q->get( 'post_type' );
	if ( $pt && 'post' !== $pt ) { return; }
	$id = br_sample_post_id();
	if ( $id ) {
		$q->set( 'post__not_in', array_merge( (array) $q->get( 'post__not_in' ), array( $id ) ) );
	}
} );


/* ---------- Full-width guard (inline, printed last in <head>) ----------
 * WordPress's own "install / wp_die" stylesheet gives <body> max-width:700px, a border, padding and a #f1f1f1 backdrop.
 * If any plugin or cache layer lets that leak onto the site, this inline block wins over every stylesheet file. */
add_action( 'wp_head', function () {
	echo '<style id="br-fullwidth">html,html body{max-width:none!important;width:auto!important;margin:0!important;padding-left:0!important;padding-right:0!important;padding-top:env(safe-area-inset-top,0px)!important;border:0!important;box-shadow:none!important;background-color:var(--bg)!important;color:var(--ink)}</style>' . "\n";
}, 9999 );
