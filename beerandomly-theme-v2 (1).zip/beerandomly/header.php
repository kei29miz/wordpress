<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
$br_active = br_active();
$br_nav    = array(
	'home'     => array( home_url( '/' ), 'Home' ),
	'explore'  => array( br_page_url( 'explore' ), 'Explore' ),
	'thoughts' => array( br_page_url( 'thoughts' ), 'Thoughts' ),
	'blog'     => array( br_page_url( 'blog' ), 'Blog posts' ),
	'about'    => array( br_page_url( 'about' ), 'About' ),
);
$br_count = max( 0, (int) wp_count_posts()->publish - ( br_sample_post_id() ? 1 : 0 ) );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php get_template_part( 'template-parts/sprite' ); ?>
<div id="readBar" aria-hidden="true"></div>
<header class="masthead"><a class="mh-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( br_name() ); ?> — home"><svg viewBox="0 0 64 64" aria-hidden="true"><use href="#logo"/></svg><span class="mh-name"><?php echo esc_html( br_name() ); ?></span></a><p class="mh-tag"><?php echo esc_html( br_tagline() ); ?></p></header>
<div class="shell">
<nav class="left" aria-label="Main"><?php
foreach ( $br_nav as $key => $item ) {
	printf(
		'<a class="nav-btn" href="%s"%s>%s<span>%s</span></a>',
		esc_url( $item[0] ),
		$br_active === $key ? ' aria-current="page"' : '',
		br_icon( $key ), // phpcs:ignore
		esc_html( $item[1] )
	);
}
?>
<a class="nav-btn" href="#" data-random><?php echo br_icon( 'random' ); // phpcs:ignore ?><span>Random</span></a><div class="spacer"></div><button class="nav-btn" data-theme-toggle><?php echo br_icon( 'moon' ); // phpcs:ignore ?><span>Theme</span></button>
<div class="tally" aria-hidden="true"><span class="tally-n"><?php echo esc_html( $br_count ); ?></span> <?php echo esc_html( _n( 'entry', 'entries', $br_count, 'beerandomly' ) ); ?> on the books</div></nav>
<main class="center">
