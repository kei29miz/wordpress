<?php
/** Fallback template: behaves like the archive. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
require get_theme_file_path( 'archive.php' );
