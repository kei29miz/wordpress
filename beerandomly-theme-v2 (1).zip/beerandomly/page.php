<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) :
	the_post();
	$slug  = get_post_field( 'post_name' );
	$about = ( 'about' === $slug );
	$url   = get_permalink();
	$title = wp_strip_all_tags( get_the_title() );
	br_topbar( $about ? 'About' : $title, 'title' );
	?>
<div class="stack"><article class="card" id="detail"><?php
if ( has_post_thumbnail() ) :
	?><div class="art-cover-img"><?php the_post_thumbnail( 'large', array( 'fetchpriority' => 'high' ) ); ?></div><?php
elseif ( $about ) :
	?><div class="cv cv-honey"><div class="art-cover"></div></div><?php
endif;
?><div class="art-in"><div class="kicker" style="margin-top:0"><span class="dot"></span><?php echo esc_html( $about ? 'About' : $title ); ?></div><h1 class="art-title"><?php the_title(); ?></h1><?php
if ( has_excerpt() ) :
	?><p class="art-sub"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p><?php
endif;
if ( $about ) :
	$loc = get_theme_mod( 'br_location', 'Quezon City' );
	?><div class="art-byline"><?php echo br_avatar(); // phpcs:ignore ?><div class="who"><b><?php echo esc_html( br_name() ); ?></b><?php echo $loc ? '<span>' . esc_html( $loc ) . '</span>' : ''; ?></div><div class="byl-acts"><?php echo br_share_btn( $url, $title ); // phpcs:ignore ?></div></div><?php
endif;
?><div class="prose dc-classic f-serif sz-m ac-honey"><?php the_content(); ?></div><?php
if ( $about ) :
	?><div class="share-box"><b>Share this page</b><div class="share-btns"><button class="btn btn-primary" data-share="<?php echo esc_url( $url ); ?>" data-title="<?php echo esc_attr( $title ); ?>"><?php echo br_icon( 'share' ); // phpcs:ignore ?>&nbsp;Share</button><button class="btn btn-outline" data-copy>Copy link</button><a class="btn btn-outline" data-net="whatsapp" target="_blank" rel="noopener">WhatsApp</a><a class="btn btn-outline" data-net="x" target="_blank" rel="noopener">X</a><a class="btn btn-outline" data-net="facebook" target="_blank" rel="noopener">Facebook</a></div></div><?php
endif;
?></div></article></div>
	<?php
endwhile;
get_footer();
