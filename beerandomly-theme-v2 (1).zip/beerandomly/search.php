<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
global $wp_query;
$n = (int) $wp_query->found_posts;
br_topbar( 'Search', 'page' );
?>
<div class="stack"><section class="card"><div class="big-search"><form class="search" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get"><?php echo br_icon( 'explore' ); // phpcs:ignore ?><input type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="Search posts, thoughts and topics" aria-label="Search"></form></div></section>
<?php if ( have_posts() ) : ?>
<section class="card feed"><div class="ex-head"><h2>“<?php echo esc_html( get_search_query() ); ?>”</h2><span class="count"><?php echo esc_html( sprintf( _n( '%d result', '%d results', $n, 'beerandomly' ), $n ) ); ?></span></div><?php
	while ( have_posts() ) { the_post(); get_template_part( 'template-parts/card' ); }
?></section>
<?php br_pagination(); ?>
<?php else : ?>
<section class="card empty"><h2>No matches</h2><p>Try a different word or topic.</p></section>
<?php endif; ?></div>
<?php get_footer(); ?>
