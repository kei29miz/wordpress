<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
$tags   = get_tags( array( 'orderby' => 'count', 'order' => 'DESC', 'number' => 6, 'hide_empty' => true ) );
$latest = new WP_Query( array(
	'posts_per_page'      => 4,
	'category__not_in'    => br_exclude_thoughts(),
	'ignore_sticky_posts' => true,
	'no_found_rows'       => true,
) );
?>
<aside class="right" aria-label="Explore"><form class="search" role="search" action="<?php echo esc_url( br_page_url( 'explore' ) ); ?>" method="get"><span><?php echo br_icon( 'explore' ); // phpcs:ignore ?></span><input type="search" name="q" placeholder="Search <?php echo esc_attr( br_name() ); ?>" aria-label="Search"></form>
<?php if ( $tags ) : ?>
<section class="card panel" style="margin-top:14px"><h2>Trending topics</h2><?php foreach ( $tags as $t ) : ?><a class="trend" href="<?php echo esc_url( get_tag_link( $t ) ); ?>"><b>#<?php echo esc_html( $t->name ); ?></b><small><?php echo esc_html( sprintf( _n( '%d post', '%d posts', $t->count, 'beerandomly' ), $t->count ) ); ?></small></a><?php endforeach; ?></section>
<?php endif; ?>
<?php if ( $latest->have_posts() ) : ?>
<section class="card panel" style="margin-top:14px"><h2>Latest</h2><?php while ( $latest->have_posts() ) : $latest->the_post(); ?><a class="trend" href="<?php the_permalink(); ?>"><b><?php the_title(); ?></b><small><time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?></time></small></a><?php endwhile; wp_reset_postdata(); ?></section>
<?php endif; ?>
<p class="foot-note"><?php echo esc_html( br_name() ); ?> · <a href="<?php echo esc_url( br_page_url( 'privacy' ) ); ?>">Privacy</a></p></aside>
