<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) :
	the_post();
	$id      = get_the_ID();
	$thought = br_is_thought();
	$url     = get_permalink();
	$title   = wp_strip_all_tags( get_the_title() );
	$tags    = get_the_tags();
	$cover   = $thought ? null : br_cover();
	$older   = get_adjacent_post( false, '', true );
	$newer   = get_adjacent_post( false, '', false );
	$more    = new WP_Query( array(
		'posts_per_page'      => 3,
		'post__not_in'        => array( $id ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	) );

	if ( $thought ) {
		br_topbar( br_thought_text(), 'backh1' );
	} else {
		br_topbar( $title, 'back' );
	}
	?>
<div class="stack"><article class="card" id="detail"><?php
if ( $cover ) :
	?><div class="art-cover-img"><img src="<?php echo esc_url( $cover['url'] ); ?>" alt="<?php echo esc_attr( $cover['alt'] ); ?>" width="<?php echo (int) $cover['w']; ?>" height="<?php echo (int) $cover['h']; ?>"<?php echo $cover['pos'] ? ' style="object-position:' . esc_attr( $cover['pos'] ) . '"' : ''; ?> fetchpriority="high"></div><?php
	if ( $cover['credit'] ) :
		?><p class="cover-credit"><?php echo wp_kses( $cover['credit'], array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ) ) ); ?></p><?php
	endif;
elseif ( ! $thought ) :
	?><div class="cv <?php echo esc_attr( br_cv_class() ); ?>"><div class="art-cover"></div></div><?php
endif;
?><div class="art-in"><div class="kicker<?php echo $thought ? ' t' : ''; ?>" style="margin-top:0"><span class="dot"></span><?php echo $thought ? 'Thought' : 'Article'; echo $tags ? ' in #' . esc_html( $tags[0]->name ) : ''; ?></div><?php
if ( $thought ) :
	?><div class="tq-panel <?php echo esc_attr( br_tc_class() ); ?>"><div class="art-quote tf-serif"><?php the_content(); ?></div></div><?php
else :
	?><h1 class="art-title"><?php the_title(); ?></h1><?php
	if ( has_excerpt() ) :
		?><p class="art-sub"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p><?php
	endif;
endif;
?><div class="art-byline"><?php echo br_avatar(); // phpcs:ignore ?><div class="who"><b><?php echo esc_html( br_name() ); ?></b><span><time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></time> · <?php echo esc_html( br_read_label() ); ?></span></div><div class="byl-acts"><?php echo br_share_btn( $url, $title ); // phpcs:ignore ?></div></div><?php
if ( ! $thought ) :
	?><div class="prose dc-classic f-serif sz-m ac-honey"><?php the_content(); ?></div><?php
endif;
if ( $tags ) :
	?><div class="tags"><?php foreach ( $tags as $t ) : ?><a class="tag" href="<?php echo esc_url( get_tag_link( $t ) ); ?>">#<?php echo esc_html( $t->name ); ?></a><?php endforeach; ?></div><?php
endif;
?>
<div class="share-box"><b>Share this <?php echo $thought ? 'thought' : 'post'; ?></b><div class="share-btns"><button class="btn btn-primary" data-share="<?php echo esc_url( $url ); ?>" data-title="<?php echo esc_attr( $title ); ?>"><?php echo br_icon( 'share' ); // phpcs:ignore ?>&nbsp;Share</button><button class="btn btn-outline" data-copy>Copy link</button><a class="btn btn-outline" data-net="whatsapp" target="_blank" rel="noopener">WhatsApp</a><a class="btn btn-outline" data-net="x" target="_blank" rel="noopener">X</a><a class="btn btn-outline" data-net="facebook" target="_blank" rel="noopener">Facebook</a></div></div>
<div class="author-box"><div class="pf-avatar"><svg viewBox="-26 -22 46 36" aria-hidden="true"><use href="#bee" transform="rotate(-12)"/></svg></div><div style="flex:1;min-width:0"><small>Written by</small><b><?php echo esc_html( br_name() ); ?></b><p><?php echo esc_html( br_bio() ); ?></p><a class="btn btn-outline" href="<?php echo esc_url( br_page_url( 'about' ) ); ?>">About me</a></div></div></div></article>
<?php if ( $older || $newer ) : ?>
<nav class="pn" aria-label="More posts"><?php
	if ( $older ) {
		echo '<a href="' . esc_url( get_permalink( $older ) ) . '"><small>Older</small><b>' . esc_html( br_short( wp_strip_all_tags( get_the_title( $older ) ), 90 ) ) . '</b></a>';
	}
	if ( $newer ) {
		echo '<a href="' . esc_url( get_permalink( $newer ) ) . '"><small>Newer</small><b>' . esc_html( br_short( wp_strip_all_tags( get_the_title( $newer ) ), 90 ) ) . '</b></a>';
	}
?></nav>
<?php endif; ?>
<?php if ( $more->have_posts() ) : ?>
<section class="more-from"><div><h2>More from <?php echo esc_html( br_name() ); ?></h2><?php
	while ( $more->have_posts() ) {
		$more->the_post();
		get_template_part( 'template-parts/card' );
	}
	wp_reset_postdata();
?></div></section>
<?php endif; ?>
</div>
	<?php
endwhile;
get_footer();
