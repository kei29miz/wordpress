<?php
/**
 * Template Name: Blog posts
 * Template Post Type: page
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$q = new WP_Query( array(
	'posts_per_page'      => 100,
	'category__not_in'    => br_exclude_thoughts(),
	'ignore_sticky_posts' => true,
	'no_found_rows'       => true,
) );
$mins = 0;
foreach ( $q->posts as $p ) { $mins += max( 1, (int) round( br_words( $p ) / 225 ) ); }
$count = count( $q->posts );
br_topbar( get_the_title(), 'page' );
?>
<div class="stack"><?php
get_template_part( 'template-parts/page-head', null, array(
	'cv'    => 'cv-honey',
	'icon'  => 'blog',
	'title' => get_the_title(),
	'sub'   => sprintf( _n( '%d post', '%d posts', $count, 'beerandomly' ), $count ) . ' · ~' . $mins . ' min of reading',
) );
?><h2 class="sr-only">All posts</h2><div class="psort"><button type="button" data-bsort="new" aria-pressed="true">Newest</button><button type="button" data-bsort="quick" aria-pressed="false">Quick reads</button></div><section class="card feed" id="blogList"><?php
while ( $q->have_posts() ) { $q->the_post(); get_template_part( 'template-parts/card' ); }
wp_reset_postdata();
?></section></div>
<?php get_footer(); ?>
