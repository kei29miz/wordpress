<?php
/**
 * Template Name: Explore
 * Template Post Type: page
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$all    = new WP_Query( array( 'posts_per_page' => 200, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
$tags   = get_tags( array( 'orderby' => 'count', 'order' => 'DESC', 'hide_empty' => true ) );
$ntags  = $tags ? count( $tags ) : 0;
br_topbar( get_the_title(), 'page' );
?>
<div class="stack"><section class="card"><div class="big-search"><label class="search"><?php echo br_icon( 'explore' ); // phpcs:ignore ?><input type="search" id="exQ" placeholder="Search posts, thoughts and topics" aria-label="Search"></label></div></section>
<div id="exResults" hidden><section class="card feed"><div class="ex-head"><h3 id="exLabel"></h3><button class="btn btn-quiet" id="exClear">Clear</button></div><div id="exNone" class="empty" hidden><h2>No matches</h2><p>Try a different word or topic.</p></div><div id="exList"><?php
while ( $all->have_posts() ) { $all->the_post(); get_template_part( 'template-parts/card' ); }
?></div></section></div>
<div id="exDefault" class="stack"><section class="card surprise"><div class="ph-icon"><?php echo br_icon( 'random' ); // phpcs:ignore ?></div><div><b>Feeling random?</b><span>Jump to any post on the blog.</span></div><button class="btn btn-primary" data-random>Surprise me</button></section>
<?php if ( $tags ) : ?>
<section class="card"><div class="ex-head"><h2>Topics</h2><span class="count"><?php echo esc_html( sprintf( _n( '%d topic', '%d topics', $ntags, 'beerandomly' ), $ntags ) ); ?></span></div><div class="topic-grid"><?php foreach ( $tags as $t ) : ?><a class="topic-card" href="<?php echo esc_url( get_tag_link( $t ) ); ?>"><b>#<?php echo esc_html( $t->name ); ?></b><small><?php echo esc_html( sprintf( _n( '%d post', '%d posts', $t->count, 'beerandomly' ), $t->count ) ); ?></small></a><?php endforeach; ?></div></section>
<?php endif; ?>
<section class="card feed"><div class="ex-head"><h2>Latest</h2></div><?php
$latest = new WP_Query( array( 'posts_per_page' => 5, 'ignore_sticky_posts' => true, 'no_found_rows' => true ) );
while ( $latest->have_posts() ) { $latest->the_post(); get_template_part( 'template-parts/card' ); }
wp_reset_postdata();
?></section></div></div>
<?php get_footer(); ?>
