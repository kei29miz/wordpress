<?php
/** Article / thought card used in feeds. Call inside the loop. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$id      = get_the_ID();
$thought = br_is_thought( $id );
$url     = get_permalink();
$title   = $thought ? br_thought_text( $id ) : wp_strip_all_tags( get_the_title() );
$tags    = get_the_tags();
$names   = $tags ? implode( ',', wp_list_pluck( $tags, 'name' ) ) : '';
$search  = mb_strtolower( mb_substr( $title . ' ' . br_text( $id ) . ' ' . str_replace( ',', ' ', $names ), 0, 2500 ) );
$cover   = $thought ? null : br_cover( $id );
$nothumb = $thought;
?>
<article class="acard<?php echo $nothumb ? ' no-thumb' : ''; ?>" data-type="<?php echo $thought ? 'thought' : 'post'; ?>" data-open="<?php echo esc_url( $url ); ?>" data-date="<?php echo esc_attr( get_post_time( 'U' ) ); ?>" data-words="<?php echo esc_attr( br_words( $id ) ); ?>" data-search="<?php echo esc_attr( $search ); ?>" data-tags="<?php echo esc_attr( $names ); ?>" tabindex="0">
<div><div class="byline"><?php echo br_avatar(); // phpcs:ignore ?><span class="nm"><?php echo esc_html( br_name() ); ?></span><span><time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?></time></span></div>
<div class="kicker<?php echo $thought ? ' t' : ''; ?>"><span class="dot"></span><?php echo $thought ? 'Thought' : 'Article'; ?></div>
<h3 class="a-title<?php echo $thought ? ' is-thought' : ''; ?>"><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $title ); ?></a></h3><?php if ( ! $thought ) : ?><p class="a-ex"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p><?php endif; ?>
<div class="a-foot"><span><?php echo esc_html( br_read_label( $id ) ); ?></span><?php if ( $tags ) : $t = $tags[0]; ?><a class="tag" href="<?php echo esc_url( get_tag_link( $t ) ); ?>">#<?php echo esc_html( $t->name ); ?></a><?php endif; ?><span class="grow"></span><div class="a-acts"><?php echo br_share_btn( $url, br_short( $title ) ); // phpcs:ignore ?></div></div></div><?php
if ( $cover ) :
	?><div class="a-thumb"><img src="<?php echo esc_url( $cover['url'] ); ?>" alt="<?php echo esc_attr( $cover['alt'] ); ?>" width="<?php echo (int) $cover['w']; ?>" height="<?php echo (int) $cover['h']; ?>"<?php echo $cover['pos'] ? ' style="object-position:' . esc_attr( $cover['pos'] ) . '"' : ''; ?> loading="lazy" decoding="async"></div><?php
elseif ( ! $nothumb ) :
	preg_match( '/[\p{L}\p{N}]/u', $title, $m );
	?><div class="a-thumb cv <?php echo esc_attr( br_cv_class( $id ) ); ?>" aria-hidden="true"><b><?php echo esc_html( isset( $m[0] ) ? mb_strtoupper( $m[0] ) : '•' ); ?></b></div><?php
endif; ?></article>
