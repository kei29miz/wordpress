<?php
/** Page header card. $args: cv, icon, title, sub */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$a = wp_parse_args( isset( $args ) ? $args : array(), array( 'cv' => 'cv-honey', 'icon' => 'blog', 'title' => '', 'sub' => '' ) );
?>
<section class="card page-head"><div class="cv <?php echo esc_attr( $a['cv'] ); ?>"><div class="ph-cover"></div></div><div class="ph-body"><div class="ph-icon"><?php echo br_icon( $a['icon'] ); // phpcs:ignore ?></div><div class="ph-text"><p class="ph-title"><?php echo esc_html( $a['title'] ); ?></p><p><?php echo esc_html( $a['sub'] ); ?></p></div></div></section>
