<svg width="0" height="0" style="position:absolute" aria-hidden="true">
  <defs>
    <clipPath id="beeClip"><ellipse cx="0" cy="0" rx="12" ry="8.5"/></clipPath>
    <g id="bee">
      <ellipse cx="-3" cy="-10" rx="5.2" ry="8.5" transform="rotate(-28 -3 -10)" fill="#E9E3FB" stroke="#1F1B16" stroke-width="2"/>
      <ellipse cx="3.5" cy="-9.5" rx="4.4" ry="7.2" transform="rotate(18 3.5 -9.5)" fill="#E9E3FB" stroke="#1F1B16" stroke-width="2"/>
      <path d="M11 -1.5 L17.5 0 L11 1.5 Z" fill="#1F1B16"/>
      <ellipse cx="0" cy="0" rx="12" ry="8.5" fill="#F9C22E"/>
      <g clip-path="url(#beeClip)" fill="#1F1B16"><rect x="-3.5" y="-10" width="3.6" height="20"/><rect x="4" y="-10" width="3.6" height="20"/></g>
      <ellipse cx="0" cy="0" rx="12" ry="8.5" fill="none" stroke="#1F1B16" stroke-width="2"/>
      <circle cx="-13.5" cy="0" r="5.4" fill="#1F1B16"/>
      <circle cx="-15" cy="-1.6" r="1.4" fill="#fff"/>
      <path d="M-15.5 -4.5 C -18 -9 -20 -10 -22 -9.5" fill="none" stroke="#1F1B16" stroke-width="1.6" stroke-linecap="round"/>
      <path d="M-12.5 -5 C -13 -10 -14.5 -12 -16.5 -12.5" fill="none" stroke="#1F1B16" stroke-width="1.6" stroke-linecap="round"/>
    </g>
    <g id="logo">
      <path d="M5 54 C 14 62, 24 46, 15 41 C 6 36, 8 55, 23 51 C 32 48.5, 30 38, 37 34" fill="none" stroke="#7562BE" stroke-width="2.6" stroke-dasharray="1.5 5.5" stroke-linecap="round"/>
      <use href="#bee" transform="translate(44 26) rotate(-24) scale(.95)"/>
    </g>
  </defs>
</svg>