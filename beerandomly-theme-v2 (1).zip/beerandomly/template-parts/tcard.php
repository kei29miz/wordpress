<?php
/** Thought card for the Thoughts grid. Call inside the loop. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$url  = get_permalink();
$text = br_thought_text();
$tags = get_the_tags();
?>
<article class="tcard" data-open="<?php echo esc_url( $url ); ?>" tabindex="0"><p class="tq"><a href="<?php echo esc_url( $url ); ?>" class="a-link"><?php echo esc_html( $text ); ?></a></p>
<div class="tmeta"><time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date( 'M j, Y' ) ); ?></time></div><?php if ( $tags ) : ?><div class="tags"><?php foreach ( array_slice( $tags, 0, 3 ) as $t ) : ?><a class="tag" href="<?php echo esc_url( get_tag_link( $t ) ); ?>">#<?php echo esc_html( $t->name ); ?></a><?php endforeach; ?></div><?php endif; ?><div class="actions"><?php echo br_share_btn( $url, br_short( $text ) ); // phpcs:ignore ?></div></article>
