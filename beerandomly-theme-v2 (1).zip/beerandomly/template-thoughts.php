<?php
/**
 * Template Name: Thoughts
 * Template Post Type: page
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$cat = br_thoughts_term_id();
$q   = new WP_Query( array(
	'posts_per_page'      => 100,
	'cat'                 => $cat ? $cat : -1,
	'ignore_sticky_posts' => true,
	'no_found_rows'       => true,
) );
$count = $cat ? count( $q->posts ) : 0;
br_topbar( get_the_title(), 'page' );
?>
<div class="stack"><?php
get_template_part( 'template-parts/page-head', null, array(
	'cv'    => 'cv-lavender',
	'icon'  => 'thoughts',
	'title' => get_the_title(),
	'sub'   => sprintf( _n( '%d thought', '%d thoughts', $count, 'beerandomly' ), $count ),
) );
if ( $count ) :
	?><div class="tgrid"><?php
	while ( $q->have_posts() ) { $q->the_post(); get_template_part( 'template-parts/tcard' ); }
	wp_reset_postdata();
	?></div><?php
else :
	?><section class="card empty"><h2>No thoughts yet</h2><p>Add a post to the “Thoughts” category and it will show up here.</p></section><?php
endif;
?></div>
<?php get_footer(); ?>
