<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
br_topbar( __( 'Page not found', 'beerandomly' ) );
?><div class="stack"><section class="card empty"><h2><?php esc_html_e( 'This page wandered off', 'beerandomly' ); ?></h2><p><?php esc_html_e( 'The link may be old or mistyped. Try one of these instead, or', 'beerandomly' ); ?> <a href="<?php echo esc_url( br_page_url( 'explore' ) ); ?>"><?php esc_html_e( 'search the blog', 'beerandomly' ); ?></a>.</p>
<p><a class="btn btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Go home', 'beerandomly' ); ?></a> <a class="btn btn-outline" href="#" data-random><?php esc_html_e( 'Surprise me', 'beerandomly' ); ?></a></p></section>
<section class="card feed"><div class="ex-head"><h2><?php esc_html_e( 'Latest', 'beerandomly' ); ?></h2></div><?php foreach ( br_posts( 'all', 4 ) as $p ) { br_acard( $p ); } ?></section></div>
<?php get_footer();
