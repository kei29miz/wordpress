<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
global $wp_query;
$title = is_tag() ? '#' . single_tag_title( '', false ) : wp_strip_all_tags( get_the_archive_title() );
br_topbar( $title );
echo '<div class="stack">';
br_page_head( $title, br_plural( (int) $wp_query->found_posts, 'post', 'posts' ), is_tag() ? 'tag' : 'blog', 'cv-lavender' );
echo '<section class="card feed">';
if ( have_posts() ) { while ( have_posts() ) { the_post(); br_acard( get_post() ); } } else { echo '<div class="empty"><h2>' . esc_html__( 'Nothing here yet', 'beerandomly' ) . '</h2></div>'; }
echo '</section>';
the_posts_pagination( array( 'prev_text' => '←', 'next_text' => '→' ) );
echo '</div>';
get_footer();
