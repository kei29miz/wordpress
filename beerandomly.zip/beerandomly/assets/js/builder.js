/* Bee Randomly — free website builder.
 * Edits a static site (index.html + css/js/images) visually in the browser and downloads it as a .zip.
 * The edited page runs in a sandboxed iframe with scripts off; Preview runs it in a separate
 * sandbox with scripts on but no access to this site. */
(function () {
'use strict';
var C = window.BRB || {}, root = document.getElementById('bld');
if (!root || !window.JSZip) return;

function $(s, r) { return (r || document).querySelector(s); }
function $$(s, r) { return [].slice.call((r || document).querySelectorAll(s)); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
var ICON = {
  x: '<svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>'
};
var TEXT_EXT = /\.(html?|css|js|mjs|json|txt|md|xml|webmanifest|map)$/i;
var MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', avif: 'image/avif', ico: 'image/x-icon', woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf', mp4: 'video/mp4', webm: 'video/webm', mp3: 'audio/mpeg', pdf: 'application/pdf' };
function ext(p) { var m = /\.([a-z0-9]+)$/i.exec(p); return m ? m[1].toLowerCase() : ''; }

/* ---------- elements ---------- */
var start = $('#bldStart'), app = $('#bldApp'), frame = $('#bldFrame'), pframe = $('#bldPreview'), canvas = $('#bldCanvas'),
  panel = $('#bldPanel'), status = $('#bldStatus'), pagesSel = $('#bldPages'), pagesWrap = $('#bldPagesWrap'),
  undoBtn = $('#bldUndo'), redoBtn = $('#bldRedo'), dlg = $('#bldDlg');

/* ---------- state ---------- */
var P = null;          // project: {name, template, entry, files:{path:{text}|{blob}}}
var doc = null;        // the edited document (inside the iframe)
var urlMap = {};       // object URL -> original reference text
var sel = null, hov = null, mode = 'edit', tab = 'el';
var hist = [], hi = -1, histT = 0, saveT = 0, uploadN = 0;

/* ---------- storage (IndexedDB, this browser only) ---------- */
var DB = null;
function db() {
  if (DB) return DB;
  DB = new Promise(function (ok, no) {
    if (!window.indexedDB) return no(new Error('no idb'));
    var r = indexedDB.open('br-builder', 1);
    r.onupgradeneeded = function () { r.result.createObjectStore('p'); };
    r.onsuccess = function () { ok(r.result); };
    r.onerror = function () { no(r.error); };
  });
  return DB;
}
function idb(op, val) {
  return db().then(function (d) {
    return new Promise(function (ok, no) {
      var t = d.transaction('p', op === 'get' ? 'readonly' : 'readwrite'), s = t.objectStore('p'), r;
      if (op === 'get') r = s.get('current'); else if (op === 'del') r = s.delete('current'); else r = s.put(val, 'current');
      r.onsuccess = function () { ok(r.result); };
      r.onerror = function () { no(r.error); };
    });
  });
}

/* ---------- paths ---------- */
function isExternal(ref) { return !ref || /^(?:[a-z][a-z0-9+.-]*:|\/\/|#)/i.test(ref.trim()); }
function resolve(base, ref) {
  ref = ref.trim().split('#')[0].split('?')[0];
  if (!ref) return '';
  try {
    var u = new URL(ref, 'http://x.invalid/' + base);
    return decodeURIComponent(u.pathname.replace(/^\/+/, ''));
  } catch (e) { return ''; }
}
function fileBlob(path) {
  var f = P.files[path];
  if (!f) return null;
  if (f.blob) return f.blob;
  if (/\.svg$/i.test(path)) return new Blob([f.text], { type: 'image/svg+xml' });
  return null;
}
function objFor(owner, ref) {
  if (isExternal(ref) || /^data:/i.test(ref)) return null;
  var b = fileBlob(resolve(owner, ref));
  if (!b) return null;
  var u = URL.createObjectURL(b);
  urlMap[u] = ref;
  return u;
}
function rewriteCss(css, owner) {
  return css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/g, function (m, q, ref) {
    var u = objFor(owner, ref);
    return u ? 'url(' + q + u + q + ')' : m;
  });
}
function unmap(s) {
  Object.keys(urlMap).forEach(function (u) { if (s.indexOf(u) > -1) s = s.split(u).join(urlMap[u]); });
  return s;
}

/* ---------- build the edit document ---------- */
var EDITOR_CSS = '[data-bld-hov]{outline:2px dashed #7562BE!important;outline-offset:2px!important;cursor:pointer}' +
  '[data-bld-sel]{outline:3px solid #F2C14E!important;outline-offset:2px!important}' +
  '[contenteditable=true]{outline:3px solid #7562BE!important;cursor:text}' +
  'html{scroll-behavior:auto!important}*{animation-duration:.001s!important;animation-delay:0s!important}' +
  '.bld-empty-img{min-height:80px;background:#eee}';

function buildEditHtml() {
  urlMap = {};
  var html = P.files[P.entry].text, d = new DOMParser().parseFromString(html, 'text/html');
  $$('link[rel~="stylesheet"][href]', d).forEach(function (l) {
    var href = l.getAttribute('href');
    if (isExternal(href)) return;
    var path = resolve(P.entry, href), f = P.files[path];
    if (!f || f.text == null) return;
    var s = d.createElement('style');
    s.setAttribute('data-bld-href', href);
    s.textContent = rewriteCss(f.text, path);
    l.parentNode.replaceChild(s, l);
  });
  $$('style:not([data-bld-href])', d).forEach(function (s) { s.textContent = rewriteCss(s.textContent, P.entry); });
  $$('[style*="url("]', d).forEach(function (el) { el.setAttribute('style', rewriteCss(el.getAttribute('style'), P.entry)); });
  $$('img[src],source[src],video[poster],input[type=image][src]', d).forEach(function (el) {
    var a = el.hasAttribute('poster') ? 'poster' : 'src', u = objFor(P.entry, el.getAttribute(a));
    if (u) el.setAttribute(a, u);
  });
  $$('img[srcset],source[srcset]', d).forEach(function (el) {
    el.setAttribute('srcset', el.getAttribute('srcset').split(',').map(function (part) {
      var bits = part.trim().split(/\s+/), u = objFor(P.entry, bits[0]);
      if (u) bits[0] = u;
      return bits.join(' ');
    }).join(', '));
  });
  var st = d.createElement('style');
  st.id = 'bld-ed';
  st.textContent = EDITOR_CSS;
  (d.head || d.documentElement).appendChild(st);
  return '<!doctype html>\n' + d.documentElement.outerHTML;
}

function loadIntoFrame(cb) {
  frame.onload = function () {
    doc = frame.contentDocument;
    if (!doc) return;
    wireDoc();
    setupPages();
    hist = []; hi = -1; snapshot(true);
    select(null);
    if (cb) cb();
  };
  frame.srcdoc = buildEditHtml();
}

/* ---------- export (clean files) ---------- */
function exportFiles() {
  var out = {}, k;
  for (k in P.files) out[k] = P.files[k];
  if (!doc) return out;
  var clone = doc.documentElement.cloneNode(true);
  var ed = clone.querySelector('#bld-ed');
  if (ed) ed.parentNode.removeChild(ed);
  $$('[data-bld-t]', clone).forEach(function (el) {
    if (el.getAttribute('data-bld-h') === '1') el.setAttribute('hidden', ''); else el.removeAttribute('hidden');
  });
  ['contenteditable', 'data-bld-sel', 'data-bld-hov', 'data-bld-t', 'data-bld-h', 'data-bld-os', 'spellcheck'].forEach(function (a) {
    $$('[' + a + ']', clone).forEach(function (el) { el.removeAttribute(a); });
  });
  $$('style[data-bld-href]', clone).forEach(function (s) {
    var href = s.getAttribute('data-bld-href'), path = resolve(P.entry, href);
    out[path] = { text: unmap(s.textContent) };
    var l = clone.ownerDocument.createElement('link');
    l.setAttribute('rel', 'stylesheet');
    l.setAttribute('href', href);
    s.parentNode.replaceChild(l, s);
  });
  var dt = /^\s*<!doctype[^>]*>/i.exec(P.files[P.entry].text);
  out[P.entry] = { text: (dt ? dt[0] : '<!doctype html>') + '\n' + unmap(clone.outerHTML) + '\n' };
  return out;
}

/* ---------- saving ---------- */
function setStatus(t) { status.textContent = t; }
function changed() {
  clearTimeout(histT); histT = setTimeout(function () { snapshot(); }, 350);
  clearTimeout(saveT); saveT = setTimeout(save, 1200);
  setStatus('Saving…');
}
function save() {
  if (!P) return;
  P.files = exportFiles();
  P.savedAt = Date.now();
  idb('put', P).then(function () { setStatus('Saved in this browser'); }, function () { setStatus('Not saved — browser storage is full or off'); });
}

/* ---------- undo / redo ---------- */
function snapshot(first) {
  if (!doc) return;
  var s = { h: doc.head.innerHTML, b: doc.body.innerHTML, page: curPage };
  if (!first && hist[hi] && hist[hi].h === s.h && hist[hi].b === s.b) return;
  hist = hist.slice(0, hi + 1); hist.push(s);
  if (hist.length > 60) hist.shift();
  hi = hist.length - 1; histBtns();
}
function restore(i) {
  var s = hist[i]; if (!s) return;
  hi = i; doc.head.innerHTML = s.h; doc.body.innerHTML = s.b;
  $$('[contenteditable],[data-bld-sel],[data-bld-hov]', doc).forEach(function (el) { el.removeAttribute('contenteditable'); el.removeAttribute('data-bld-sel'); el.removeAttribute('data-bld-hov'); });
  sel = null; hov = null; setupPages(s.page); render(); histBtns();
  clearTimeout(saveT); saveT = setTimeout(save, 800); setStatus('Saving…');
}
function undo() { clearTimeout(histT); snapshot(); if (hi > 0) restore(hi - 1); }
function redo() { if (hi < hist.length - 1) restore(hi + 1); }
function histBtns() { undoBtn.disabled = hi <= 0; redoBtn.disabled = hi >= hist.length - 1; }

/* ---------- pages (sites that show one [data-page] at a time) ---------- */
var curPage = '';
function setupPages(want) {
  var pages = $$('[data-page]', doc);
  pagesWrap.hidden = pages.length < 2;
  pagesSel.innerHTML = '';
  if (pages.length < 2) { curPage = ''; return; }
  pages.forEach(function (p) {
    if (!p.hasAttribute('data-bld-t')) { p.setAttribute('data-bld-t', ''); p.setAttribute('data-bld-h', p.hasAttribute('hidden') ? '1' : '0'); }
    var v = p.getAttribute('data-page'), o = document.createElement('option');
    o.value = v; o.textContent = 'Page: ' + v.replace(/[-_]+/g, ' ').replace(/^./, function (c) { return c.toUpperCase(); });
    pagesSel.appendChild(o);
  });
  var names = pages.map(function (p) { return p.getAttribute('data-page'); });
  showPage(names.indexOf(want) > -1 ? want : (names.indexOf(curPage) > -1 ? curPage : (names.indexOf('home') > -1 ? 'home' : names[0])));
}
function showPage(v) {
  curPage = v; pagesSel.value = v;
  $$('[data-page]', doc).forEach(function (p) { if (p.getAttribute('data-page') === v) p.removeAttribute('hidden'); else p.setAttribute('hidden', ''); });
  doc.defaultView.scrollTo(0, 0);
}
pagesSel.addEventListener('change', function () { select(null); showPage(pagesSel.value); });

/* ---------- selecting & inline editing ---------- */
var INLINE = /^(B|STRONG|EM|I|U|SPAN|BR|A|SMALL|SUP|SUB|MARK|CODE|S|ABBR|TIME)$/;
var TEXTY = /^(H[1-6]|P|LI|A|BUTTON|SPAN|LABEL|STRONG|EM|B|I|SMALL|BLOCKQUOTE|FIGCAPTION|TD|TH|DT|DD|SUMMARY|LEGEND|CITE|Q|TIME|CAPTION|DIV)$/;
function isTextLeaf(el) {
  if (!TEXTY.test(el.tagName) || !el.textContent.trim()) return false;
  for (var c = el.firstElementChild; c; c = c.nextElementSibling) {
    if (!INLINE.test(c.tagName) || c.querySelector('img,svg,video,iframe')) return false;
  }
  return true;
}
function pickTarget(t) {
  if (!t || t.nodeType !== 1) return null;
  var svg = t.closest('svg'); if (svg) t = svg;
  if (t === doc.documentElement || t === doc.body) return null;
  return t;
}
function wireDoc() {
  var w = doc.defaultView;
  doc.addEventListener('mouseover', function (e) {
    if (mode !== 'edit') return;
    var t = pickTarget(e.target);
    if (hov && hov !== t) hov.removeAttribute('data-bld-hov');
    hov = t;
    if (t && t !== sel && t.getAttribute('contenteditable') !== 'true') t.setAttribute('data-bld-hov', '');
  });
  doc.addEventListener('mouseout', function (e) { if (e.target && e.target.removeAttribute) e.target.removeAttribute('data-bld-hov'); });
  doc.addEventListener('click', function (e) {
    var t = pickTarget(e.target);
    if (t && t.getAttribute('contenteditable') === 'true') return;
    var inEditable = e.target.closest && e.target.closest('[contenteditable=true]');
    if (inEditable) return;
    e.preventDefault(); e.stopPropagation();
    select(t);
  }, true);
  doc.addEventListener('submit', function (e) { e.preventDefault(); }, true);
  doc.addEventListener('input', function () { changed(); });
  doc.addEventListener('paste', function (e) {
    var ed = e.target.closest && e.target.closest('[contenteditable=true]');
    if (!ed) return;
    e.preventDefault();
    var text = (e.clipboardData || w.clipboardData).getData('text/plain');
    doc.execCommand('insertText', false, text);
  });
  doc.addEventListener('keydown', function (e) {
    var ed = e.target.closest && e.target.closest('[contenteditable=true]');
    if (ed) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ed.blur(); }
      if (e.key === 'Escape') ed.blur();
      return;
    }
    keys(e);
  });
  doc.addEventListener('focusout', function (e) {
    var t = e.target;
    if (t && t.getAttribute && t.getAttribute('contenteditable') === 'true') { t.removeAttribute('contenteditable'); t.removeAttribute('spellcheck'); changed(); }
  });
}
function keys(e) {
  var mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
  if (mod && k === 'z' && !e.shiftKey) { e.preventDefault(); undo(); }
  else if (mod && (k === 'y' || (k === 'z' && e.shiftKey))) { e.preventDefault(); redo(); }
  else if (!mod && (e.key === 'Delete' || e.key === 'Backspace') && sel) { e.preventDefault(); act('del'); }
  else if (e.key === 'Escape' && sel) { select(sel.parentElement === doc.body ? null : sel.parentElement); }
}
document.addEventListener('keydown', function (e) {
  if (app.hidden || mode !== 'edit' || dlg.open) return;
  var t = e.target;
  if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
  keys(e);
});

function select(el) {
  if (sel && sel !== el) { sel.removeAttribute('data-bld-sel'); if (sel.getAttribute('contenteditable') === 'true') sel.blur(); }
  sel = el && el.isConnected ? el : null;
  if (sel) {
    sel.removeAttribute('data-bld-hov');
    sel.setAttribute('data-bld-sel', '');
    if (isTextLeaf(sel)) {
      sel.setAttribute('contenteditable', 'true');
      sel.setAttribute('spellcheck', 'true');
      sel.focus({ preventScroll: true });
    }
  }
  if (tab !== 'el' && sel) setTab('el'); else render();
}

/* ---------- element names ---------- */
function kind(el) {
  var t = el.tagName, c = (el.getAttribute('class') || '').toLowerCase();
  if (t === 'IMG') return 'Image';
  if (t === 'svg' || t === 'SVG') return 'Icon';
  if (t === 'A') return /btn|button/.test(c) ? 'Button' : 'Link';
  if (t === 'BUTTON') return 'Button';
  if (/^H[1-6]$/.test(t)) return 'Heading';
  if (t === 'P') return 'Text';
  if (t === 'LI') return 'List item';
  if (t === 'UL' || t === 'OL') return 'List';
  if (t === 'SECTION') return 'Section';
  if (t === 'HEADER') return 'Header';
  if (t === 'FOOTER') return 'Footer';
  if (t === 'NAV') return 'Menu';
  if (t === 'FORM') return 'Form';
  if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') return 'Form field';
  if (t === 'LABEL') return 'Label';
  if (t === 'IFRAME' || c.indexOf('bld-video') > -1) return 'Video';
  if (t === 'VIDEO') return 'Video';
  if (isTextLeaf(el)) return 'Text';
  return 'Box';
}
function crumbsOf(el) {
  var a = [], p = el.parentElement;
  while (p && p !== doc.body && a.length < 4) { a.unshift(p); p = p.parentElement; }
  return a;
}

/* ---------- colors ---------- */
function toHex(c) {
  if (!c) return '#000000';
  if (c[0] === '#') { if (c.length === 4) return '#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3]; return c.slice(0, 7).toLowerCase(); }
  var m = /rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/.exec(c);
  if (!m) return '#000000';
  return '#' + [m[1], m[2], m[3]].map(function (n) { return ('0' + (+n).toString(16)).slice(-2); }).join('');
}
function transparent(c) { return !c || c === 'transparent' || /rgba\([^)]*,\s*0\)$/.test(c); }

/* ---------- panel ---------- */
function setTab(t) {
  tab = t;
  $$('[data-ptab]').forEach(function (b) { b.setAttribute('aria-selected', b.dataset.ptab === t); });
  render();
}
$$('[data-ptab]').forEach(function (b) { b.addEventListener('click', function () { setTab(b.dataset.ptab); }); });

function render() {
  if (!doc) { panel.innerHTML = ''; return; }
  if (tab === 'add') return renderAdd();
  if (tab === 'site') return renderSite();
  renderEl();
}

function styleRow(label, prop, type, extra) {
  var cs = doc.defaultView.getComputedStyle(sel), v = cs[prop], has = !!sel.style[prop], input;
  if (type === 'color') {
    var val = transparent(v) ? '#ffffff' : toHex(v);
    input = '<input type="color" data-sp="' + prop + '" value="' + val + '" aria-label="' + esc(label) + '">';
  } else {
    input = '<input type="number" data-sp="' + prop + '" data-unit="px" min="' + (extra && extra.min || 0) + '" max="' + (extra && extra.max || 400) + '" value="' + (parseFloat(v) ? Math.round(parseFloat(v)) : 0) + '" aria-label="' + esc(label) + ' in pixels">';
  }
  return '<div class="bp-row"><span>' + esc(label) + '</span>' + input +
    '<button type="button" class="bp-x" data-clear="' + prop + '" title="Reset" aria-label="Reset ' + esc(label) + '"' + (has ? '' : ' hidden') + '>' + ICON.x + '</button></div>';
}

function renderEl() {
  if (!sel || !sel.isConnected) {
    sel = null;
    panel.innerHTML = '<div class="bp-empty"><b>Click anything on your page</b>Text, buttons, images and whole sections can be changed. Click text to type over it.</div>' +
      '<div class="bp-sec"><h4>Tips</h4><p class="bp-hint">Use “Select parent” to grab the whole section around what you clicked. Press Delete to remove the selected item, Ctrl+Z to undo.</p></div>';
    return;
  }
  var k = kind(sel), t = sel.tagName, h = '';
  h += '<div class="bp-title"><b>' + k + '</b><small>&lt;' + t.toLowerCase() + '&gt;</small></div>';
  var cr = crumbsOf(sel);
  if (cr.length) {
    h += '<div class="bp-crumbs" aria-label="Inside">' + cr.map(function (p, i) { return '<button type="button" data-crumb="' + i + '">' + kind(p) + '</button>'; }).join('') + '</div>';
  }
  h += '<div class="bp-acts">' +
    '<button type="button" class="btn btn-outline" data-act="up">Move up</button>' +
    '<button type="button" class="btn btn-outline" data-act="down">Move down</button>' +
    '<button type="button" class="btn btn-outline" data-act="parent">Select parent</button>' +
    '<button type="button" class="btn btn-outline" data-act="dup">Duplicate</button>' +
    '<button type="button" class="btn btn-outline danger" data-act="del">Delete</button>' +
    '<button type="button" class="btn btn-outline" data-act="none">Done</button></div>';

  if (isTextLeaf(sel)) h += '<p class="bp-hint">Type directly on the page to change this text. Press Enter when you’re done.</p>';

  // Content
  var content = '';
  if (t === 'A') {
    content += '<label class="bp-full"><span>Link goes to</span><input type="url" data-attr="href" value="' + esc(sel.getAttribute('href') || '') + '" placeholder="https://… or #contact"></label>' +
      '<label class="bp-full"><input type="checkbox" data-newtab' + (sel.getAttribute('target') === '_blank' ? ' checked' : '') + '> Open in a new tab</label>';
  }
  if (t === 'IMG') {
    content += '<div class="bp-file"><label class="btn btn-primary">Replace image<input type="file" accept="image/*" data-img="src"></label></div>' +
      '<label class="bp-full" style="margin-top:10px"><span>Description (for screen readers and Google)</span><input type="text" data-attr="alt" value="' + esc(sel.getAttribute('alt') || '') + '"></label>';
  }
  if (t === 'IFRAME' || (sel.classList && sel.classList.contains('bld-video'))) {
    var fr = t === 'IFRAME' ? sel : sel.querySelector('iframe');
    if (fr) content += '<label class="bp-full"><span>YouTube or Vimeo link</span><input type="url" data-video value="' + esc(fr.getAttribute('src') || '') + '" placeholder="https://www.youtube.com/watch?v=…"></label>';
  }
  if (t === 'INPUT' || t === 'TEXTAREA') {
    content += '<label class="bp-full"><span>Placeholder</span><input type="text" data-attr="placeholder" value="' + esc(sel.getAttribute('placeholder') || '') + '"></label>';
  }
  if (t === 'FORM') {
    content += '<label class="bp-full"><span>Send form to (e.g. a Formspree link)</span><input type="url" data-attr="action" value="' + esc(sel.getAttribute('action') || '') + '" placeholder="https://formspree.io/f/…"></label>' +
      '<p class="bp-hint">Static hosts can’t receive form messages by themselves. A free service like Formspree gives you a link to paste here; also set the form method to POST below.</p>' +
      '<div class="bp-row"><span>Method</span><select data-attr="method"><option value="">GET</option><option value="post"' + (/post/i.test(sel.getAttribute('method') || '') ? ' selected' : '') + '>POST</option></select><span></span></div>';
  }
  if (content) h += '<div class="bp-sec"><h4>Content</h4>' + content + '</div>';

  // Style
  var s = '';
  var texty = isTextLeaf(sel) || /^(A|BUTTON|H[1-6]|P|LI|LABEL)$/.test(t);
  if (texty) {
    s += styleRow('Text color', 'color', 'color') + styleRow('Text size', 'fontSize', 'num', { min: 8, max: 160 });
    var fw = parseInt(doc.defaultView.getComputedStyle(sel).fontWeight, 10) >= 600;
    var ta = doc.defaultView.getComputedStyle(sel).textAlign;
    s += '<div class="bp-row"><span>Weight</span><div class="bp-seg"><button type="button" data-fw="400" aria-pressed="' + !fw + '">Normal</button><button type="button" data-fw="700" aria-pressed="' + fw + '">Bold</button></div><span></span></div>';
    s += '<div class="bp-row"><span>Align</span><div class="bp-seg">' + ['left', 'center', 'right'].map(function (a) {
      return '<button type="button" data-ta="' + a + '" aria-pressed="' + (ta === a || (a === 'left' && ta === 'start')) + '">' + a[0].toUpperCase() + a.slice(1) + '</button>';
    }).join('') + '</div><span></span></div>';
  }
  if (t !== 'IMG' && !(t === 'svg' || t === 'SVG')) s += styleRow('Background', 'backgroundColor', 'color');
  if (t === 'IMG') s += styleRow('Width', 'width', 'num', { min: 20, max: 2000 });
  s += styleRow('Space above', 'paddingTop', 'num') + styleRow('Space below', 'paddingBottom', 'num') + styleRow('Rounded corners', 'borderRadius', 'num', { max: 200 });
  if (t !== 'IMG' && !(t === 'svg' || t === 'SVG')) {
    var hasBg = /url\(/.test(sel.style.backgroundImage || '');
    s += '<div class="bp-file"><label class="btn btn-outline">' + (hasBg ? 'Change' : 'Add') + ' background image<input type="file" accept="image/*" data-img="bg"></label>' +
      (hasBg ? '<button type="button" class="btn btn-quiet" data-bgclear>Remove it</button>' : '') + '</div>';
  }
  if (sel.hasAttribute('data-bld-os')) s += '<p style="margin:12px 0 0"><button type="button" class="btn btn-quiet" data-resetstyle>Undo all style changes on this item</button></p>';
  h += '<div class="bp-sec"><h4>Style</h4>' + s + '</div>';
  panel.innerHTML = h;
}

function keepOrigStyle(el) { if (!el.hasAttribute('data-bld-os')) el.setAttribute('data-bld-os', el.getAttribute('style') || ''); }

panel.addEventListener('click', function (e) {
  var b = e.target.closest('button'); if (!b || !doc) return;
  if (b.dataset.act) return act(b.dataset.act);
  if (b.dataset.crumb != null && sel) { var cr = crumbsOf(sel); return select(cr[+b.dataset.crumb]); }
  if (b.dataset.clear && sel) { sel.style[b.dataset.clear] = ''; cleanStyle(sel); changed(); return render(); }
  if (b.dataset.fw && sel) { keepOrigStyle(sel); sel.style.fontWeight = b.dataset.fw; changed(); return render(); }
  if (b.dataset.ta && sel) { keepOrigStyle(sel); sel.style.textAlign = b.dataset.ta; changed(); return render(); }
  if (b.hasAttribute('data-bgclear') && sel) { sel.style.backgroundImage = ''; sel.style.backgroundSize = ''; sel.style.backgroundPosition = ''; cleanStyle(sel); changed(); return render(); }
  if (b.hasAttribute('data-resetstyle') && sel) { var o = sel.getAttribute('data-bld-os'); if (o) sel.setAttribute('style', o); else sel.removeAttribute('style'); sel.removeAttribute('data-bld-os'); changed(); return render(); }
  if (b.dataset.block) return addBlock(b.dataset.block);
});
function cleanStyle(el) { if (!el.getAttribute('style') || !el.getAttribute('style').trim()) el.removeAttribute('style'); }

panel.addEventListener('input', function (e) {
  var i = e.target; if (!doc) return;
  if (i.dataset.sp && sel) {
    keepOrigStyle(sel);
    sel.style[i.dataset.sp] = i.type === 'color' ? i.value : (i.value === '' ? '' : i.value + 'px');
    var x = i.parentNode.querySelector('.bp-x'); if (x) x.hidden = false;
    changed();
  } else if (i.dataset.attr && sel && i.tagName !== 'SELECT') {
    if (i.value) sel.setAttribute(i.dataset.attr, i.value); else sel.removeAttribute(i.dataset.attr);
    changed();
  } else if (i.dataset.cssvar) {
    setCssVar(i.dataset.cssvar, i.value); changed();
  } else if (i.dataset.site) {
    siteField(i.dataset.site, i.value); changed();
  }
});
panel.addEventListener('change', function (e) {
  var i = e.target; if (!doc) return;
  if (i.dataset.attr && i.tagName === 'SELECT' && sel) { if (i.value) sel.setAttribute(i.dataset.attr, i.value); else sel.removeAttribute(i.dataset.attr); changed(); }
  if (i.hasAttribute('data-newtab') && sel) {
    if (i.checked) { sel.setAttribute('target', '_blank'); sel.setAttribute('rel', 'noopener'); } else { sel.removeAttribute('target'); sel.removeAttribute('rel'); }
    changed();
  }
  if (i.hasAttribute('data-video') && sel) {
    var fr = sel.tagName === 'IFRAME' ? sel : sel.querySelector('iframe'), u = embedUrl(i.value);
    if (fr && u) { fr.setAttribute('src', u); changed(); } else if (i.value) { i.setCustomValidity('Paste a YouTube or Vimeo link'); i.reportValidity(); }
  }
  if (i.dataset.img && i.files && i.files[0] && sel) useImage(i.files[0], i.dataset.img);
  if (i.dataset.font) { setFont(i.dataset.font, i.value); changed(); }
});

function embedUrl(v) {
  var m = /(?:youtu\.be\/|v=|embed\/|shorts\/)([\w-]{11})/.exec(v);
  if (m) return 'https://www.youtube-nocookie.com/embed/' + m[1];
  m = /vimeo\.com\/(?:video\/)?(\d+)/.exec(v);
  if (m) return 'https://player.vimeo.com/video/' + m[1];
  return '';
}

function useImage(file, where) {
  if (!/^image\//.test(file.type)) return alert('Choose an image file (JPG, PNG, WebP, GIF or SVG).');
  if (file.size > 8 * 1024 * 1024) return alert('That image is over 8 MB. Make it smaller first so your site loads fast.');
  var e = ext(file.name) || (file.type.split('/')[1] || 'png').replace('jpeg', 'jpg').replace('svg+xml', 'svg');
  var base = (file.name.replace(/\.[^.]+$/, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'image').slice(0, 40), path;
  do { uploadN++; path = 'images/' + base + (uploadN > 1 ? '-' + uploadN : '') + '.' + e; } while (P.files[path]);
  P.files[path] = { blob: file };
  var u = URL.createObjectURL(file);
  var rel = relFromEntry(path);
  urlMap[u] = rel;
  if (where === 'src') { sel.setAttribute('src', u); sel.removeAttribute('srcset'); var pic = sel.closest('picture'); if (pic) $$('source', pic).forEach(function (s) { s.parentNode.removeChild(s); }); }
  else { keepOrigStyle(sel); sel.style.backgroundImage = 'url("' + u + '")'; sel.style.backgroundSize = 'cover'; sel.style.backgroundPosition = 'center'; }
  changed(); render();
}
function relFromEntry(path) {
  var depth = P.entry.split('/').length - 1, up = '';
  for (var i = 0; i < depth; i++) up += '../';
  return up + path;
}

/* Scroll inside the canvas only (scrolling the element into view would also scroll this page). */
function reveal(el, center) {
  var w = doc.defaultView, r = el.getBoundingClientRect(), vh = w.innerHeight;
  if (center) w.scrollBy(0, r.top - (vh - Math.min(r.height, vh)) / 2);
  else if (r.top < 0) w.scrollBy(0, r.top - 20);
  else if (r.bottom > vh) w.scrollBy(0, Math.min(r.top - 20, r.bottom - vh + 20));
}

/* ---------- actions ---------- */
function act(a) {
  if (a === 'none') return select(null);
  if (!sel) return;
  var el = sel;
  if (a === 'parent') { if (el.parentElement && el.parentElement !== doc.body) select(el.parentElement); return; }
  if (a === 'up') { var pv = el.previousElementSibling; if (pv) { el.parentNode.insertBefore(el, pv); changed(); reveal(el); } return; }
  if (a === 'down') { var nx = el.nextElementSibling; if (nx) { el.parentNode.insertBefore(nx, el); changed(); reveal(el); } return; }
  if (a === 'dup') {
    var c = el.cloneNode(true);
    c.removeAttribute('data-bld-sel'); c.removeAttribute('contenteditable');
    $$('[id]', c).concat(c.id ? [c] : []).forEach(function (n) { n.removeAttribute('id'); });
    el.parentNode.insertBefore(c, el.nextSibling); changed(); select(c); return;
  }
  if (a === 'del') {
    if (el.matches('main,[data-page]')) { alert('This holds a whole page, so it can’t be deleted. Select something inside it instead.'); return; }
    var next = el.nextElementSibling || el.previousElementSibling || el.parentElement;
    el.parentNode.removeChild(el); sel = null; changed(); select(next && next !== doc.body ? next : null);
  }
}

/* ---------- block library ---------- */
var IMG_PH = 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="520" viewBox="0 0 800 520"><rect width="800" height="520" fill="#d9d4c7"/><path d="M250 360l110-120 80 90 60-60 100 90z" fill="#b5ad9a"/><circle cx="520" cy="190" r="34" fill="#b5ad9a"/></svg>');
var BLOCK_CSS = '.bld-b{padding:64px 22px}.bld-b .bld-w{max-width:1080px;margin:0 auto}' +
  '.bld-b h2{margin:0 0 .4em}.bld-b p{max-width:65ch}' +
  '.bld-b-split .bld-w{display:grid;grid-template-columns:1fr 1fr;gap:36px;align-items:center}' +
  '.bld-b img{max-width:100%;height:auto;display:block;border-radius:12px}' +
  '.bld-b-cols{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:22px;margin-top:22px}' +
  '.bld-b-card{padding:22px;border:1px solid rgba(127,127,127,.25);border-radius:14px}' +
  '.bld-b-card h3{margin:0 0 .3em}' +
  '.bld-b-gallery{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-top:22px}' +
  '.bld-b-cta{text-align:center;background:var(--accent,#222);color:var(--bg,#fff)}.bld-b-cta p{margin-left:auto;margin-right:auto}' +
  '.bld-b-cta .bld-btn{background:var(--bg,#fff);color:var(--accent,#222)}' +
  '.bld-btn{display:inline-block;margin-top:10px;padding:12px 22px;border-radius:999px;background:var(--accent,#222);color:var(--bg,#fff);text-decoration:none;font-weight:700}' +
  '.bld-b-quote blockquote{margin:0;font-size:1.4em;line-height:1.4;max-width:40ch}.bld-b-quote cite{display:block;margin-top:12px;font-style:normal;opacity:.75}' +
  '.bld-b-faq details{border-top:1px solid rgba(127,127,127,.3);padding:14px 0}.bld-b-faq summary{cursor:pointer;font-weight:700}' +
  '.bld-video{position:relative;aspect-ratio:16/9;margin-top:18px}.bld-video iframe{position:absolute;inset:0;width:100%;height:100%;border:0;border-radius:12px}' +
  '.bld-spacer{height:60px}.bld-hr{border:0;border-top:1px solid rgba(127,127,127,.35);margin:24px auto;max-width:1080px}' +
  '@media (max-width:720px){.bld-b-split .bld-w{grid-template-columns:1fr}}';
var BLOCKS = [
  ['text', 'Heading and text', 'A title with a paragraph', '<section class="bld-b"><div class="bld-w"><h2>Your heading here</h2><p>Write a few sentences here. Click to change this text.</p></div></section>'],
  ['split', 'Image and text', 'Picture beside words', '<section class="bld-b bld-b-split"><div class="bld-w"><img src="' + IMG_PH + '" alt=""><div><h2>Tell your story</h2><p>Explain what you do and who it helps. Click the image to replace it.</p><a class="bld-btn" href="#contact">Get in touch</a></div></div></section>'],
  ['cols', 'Three columns', 'Services or features', '<section class="bld-b"><div class="bld-w"><h2>What I offer</h2><div class="bld-b-cols"><div class="bld-b-card"><h3>First service</h3><p>Describe it in a sentence or two.</p></div><div class="bld-b-card"><h3>Second service</h3><p>Describe it in a sentence or two.</p></div><div class="bld-b-card"><h3>Third service</h3><p>Describe it in a sentence or two.</p></div></div></div></section>'],
  ['cta', 'Call to action', 'Big message with a button', '<section class="bld-b bld-b-cta"><div class="bld-w"><h2>Ready to start?</h2><p>One short line that tells visitors what to do next.</p><a class="bld-btn" href="#contact">Book a call</a></div></section>'],
  ['gallery', 'Image gallery', 'Three pictures in a row', '<section class="bld-b"><div class="bld-w"><h2>Recent work</h2><div class="bld-b-gallery"><img src="' + IMG_PH + '" alt=""><img src="' + IMG_PH + '" alt=""><img src="' + IMG_PH + '" alt=""></div></div></section>'],
  ['quote', 'Testimonial', 'A quote from a client', '<section class="bld-b bld-b-quote"><div class="bld-w"><blockquote>“Working together was easy and the results spoke for themselves.”</blockquote><cite>Client name, Company</cite></div></section>'],
  ['faq', 'Questions and answers', 'Click to open each answer', '<section class="bld-b bld-b-faq"><div class="bld-w"><h2>Questions</h2><details><summary>How do we get started?</summary><p>Answer the question here.</p></details><details><summary>How much does it cost?</summary><p>Answer the question here.</p></details></div></section>'],
  ['video', 'Video', 'YouTube or Vimeo', '<section class="bld-b"><div class="bld-w"><h2>Watch</h2><div class="bld-video"><iframe src="https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ" title="Video" loading="lazy" allowfullscreen></iframe></div></div></section>'],
  ['button', 'Button', 'A single button', '<div class="bld-b" style="padding-top:12px;padding-bottom:12px"><div class="bld-w"><a class="bld-btn" href="#contact">Click me</a></div></div>'],
  ['spacer', 'Space', 'Empty gap', '<div class="bld-spacer"></div>'],
  ['hr', 'Divider', 'A thin line', '<hr class="bld-hr">']
];
function renderAdd() {
  var where = sel ? 'after the selected item’s section' : 'at the end of this page';
  panel.innerHTML = '<p class="bp-hint">New blocks are added ' + where + ' and use your site’s colors.</p><div class="bp-blocks">' +
    BLOCKS.map(function (b) { return '<button type="button" class="bp-block" data-block="' + b[0] + '"><b>' + b[1] + '</b><small>' + b[2] + '</small></button>'; }).join('') + '</div>';
}
function addBlock(id) {
  var b = BLOCKS.filter(function (x) { return x[0] === id; })[0]; if (!b) return;
  if (!doc.getElementById('bld-blocks')) {
    var st = doc.createElement('style'); st.id = 'bld-blocks'; st.textContent = BLOCK_CSS;
    var ed = doc.getElementById('bld-ed');
    doc.head.insertBefore(st, ed);
  }
  var tmp = doc.createElement('div'); tmp.innerHTML = b[3];
  var node = tmp.firstElementChild, anchor = null, parent = null;
  if (sel) {
    anchor = sel;
    var container = sel.closest('[data-page]') || sel.closest('main') || doc.body;
    while (anchor.parentElement && anchor.parentElement !== container && anchor.parentElement !== doc.body) anchor = anchor.parentElement;
    parent = anchor.parentElement;
  } else {
    parent = curPage ? doc.querySelector('[data-page="' + curPage + '"]') : (doc.querySelector('main') || doc.body);
  }
  if (anchor) parent.insertBefore(node, anchor.nextSibling); else parent.appendChild(node);
  changed();
  reveal(node, true);
  setTab('el'); select(node);
}

/* ---------- site settings ---------- */
var FONTS = ['Inter', 'DM Sans', 'Work Sans', 'Poppins', 'Montserrat', 'Outfit', 'Manrope', 'Space Grotesk', 'Archivo', 'Unbounded', 'Fraunces', 'Playfair Display', 'Lora', 'Merriweather', 'DM Serif Display', 'Caveat'];
function cssStyles() { return $$('style[data-bld-href]', doc).concat($$('style:not(#bld-ed):not(#bld-blocks):not([data-bld-href])', doc)); }
function rootBlock(css) {
  var m = /:root\s*\{/.exec(css); if (!m) return null;
  var s = m.index + m[0].length, e = css.indexOf('}', s);
  return e < 0 ? null : { s: s, e: e, body: css.slice(s, e) };
}
function cssVars() {
  var out = [];
  cssStyles().forEach(function (st) {
    var rb = rootBlock(st.textContent); if (!rb) return;
    var re = /(--[\w-]+)\s*:\s*([^;]+);/g, m;
    while ((m = re.exec(rb.body))) {
      if (out.some(function (o) { return o.name === m[1]; })) continue;
      out.push({ name: m[1], val: m[2].trim(), st: st });
    }
  });
  return out;
}
function setCssVar(name, val) {
  cssStyles().some(function (st) {
    var css = st.textContent, rb = rootBlock(css); if (!rb) return false;
    var re = new RegExp('(' + name.replace(/[-]/g, '\\-') + '\\s*:\\s*)([^;]+)(;)');
    if (!re.test(rb.body)) return false;
    st.textContent = css.slice(0, rb.s) + rb.body.replace(re, '$1' + val + '$3') + css.slice(rb.e);
    return true;
  });
}
function isColor(v) { return /^#[0-9a-f]{3,8}$/i.test(v) || /^rgba?\(/i.test(v); }
function nice(n) { return n.replace(/^--/, '').replace(/[-_]+/g, ' ').replace(/^./, function (c) { return c.toUpperCase(); }); }
function fontOf(val) { var m = /^\s*["']?([^"',]+)/.exec(val || ''); return m ? m[1].trim() : ''; }
function loadFontLink(name) {
  if (!name) return;
  var id = 'bld-font-' + name.replace(/\s+/g, '-').toLowerCase();
  if (doc.getElementById(id)) return;
  var l = doc.createElement('link');
  l.id = id; l.rel = 'stylesheet';
  l.href = 'https://fonts.googleapis.com/css2?family=' + name.replace(/\s+/g, '+') + ':wght@400;500;600;700&display=swap';
  doc.head.insertBefore(l, doc.head.firstChild);
}
function setFont(target, name) {
  loadFontLink(name);
  var stack = '"' + name + '", ' + (/Serif|Fraunces|Playfair|Lora|Merriweather/.test(name) ? 'Georgia, serif' : /Caveat/.test(name) ? 'cursive' : 'system-ui, sans-serif');
  if (target.indexOf('--') === 0) { setCssVar(target, stack); return; }
  var st = doc.getElementById('bld-site-font');
  if (!st) { st = doc.createElement('style'); st.id = 'bld-site-font'; doc.head.insertBefore(st, doc.getElementById('bld-ed')); }
  st.textContent = 'body{font-family:' + stack + '}';
}
function siteField(k, v) {
  if (k === 'title') {
    var t = doc.querySelector('title'); if (!t) { t = doc.createElement('title'); doc.head.appendChild(t); }
    t.textContent = v;
  } else if (k === 'desc') {
    var m = doc.querySelector('meta[name="description"]');
    if (!m) { m = doc.createElement('meta'); m.setAttribute('name', 'description'); doc.head.appendChild(m); }
    m.setAttribute('content', v);
  }
}
function renderSite() {
  var t = doc.querySelector('title'), d = doc.querySelector('meta[name="description"]'), vars = cssVars(), h = '';
  h += '<div class="bp-sec" style="border:0;margin:0;padding:0"><h4>Name and description</h4>' +
    '<label class="bp-full"><span>Site title (shown in the browser tab and Google)</span><input type="text" data-site="title" value="' + esc(t ? t.textContent : '') + '"></label>' +
    '<label class="bp-full"><span>Short description (shown in Google results)</span><textarea data-site="desc" maxlength="300">' + esc(d ? d.getAttribute('content') : '') + '</textarea></label></div>';
  var colors = vars.filter(function (v) { return isColor(v.val); });
  if (colors.length) {
    h += '<div class="bp-sec"><h4>Colors</h4><p class="bp-hint">These change the colors everywhere on your site (light mode).</p>' +
      colors.slice(0, 14).map(function (v) {
        return '<div class="bp-row"><span>' + esc(nice(v.name)) + '</span><input type="color" data-cssvar="' + v.name + '" value="' + toHex(v.val) + '" aria-label="' + esc(nice(v.name)) + '"><span></span></div>';
      }).join('') + '</div>';
  }
  var fonts = vars.filter(function (v) { return /font/i.test(v.name) && !/size|weight/i.test(v.name); });
  var opts = function (cur) {
    var list = FONTS.slice(); if (cur && list.indexOf(cur) < 0) list.unshift(cur);
    return list.map(function (f) { return '<option' + (f === cur ? ' selected' : '') + '>' + esc(f) + '</option>'; }).join('');
  };
  h += '<div class="bp-sec"><h4>Fonts</h4>';
  if (fonts.length) {
    h += fonts.map(function (v) { return '<div class="bp-row"><span>' + esc(nice(v.name)) + '</span><select data-font="' + v.name + '">' + opts(fontOf(v.val)) + '</select><span></span></div>'; }).join('');
  } else {
    var cur = fontOf(doc.defaultView.getComputedStyle(doc.body).fontFamily);
    h += '<div class="bp-row"><span>Whole site</span><select data-font="body">' + opts(cur) + '</select><span></span></div>';
  }
  h += '</div><div class="bp-sec"><h4>Putting it online</h4><p class="bp-hint">Download the .zip, then upload it to Cloudflare Pages (Workers &amp; Pages → Create → Pages → Upload assets), or unzip it and deploy the folder on Vercel. Both have free plans. The .zip includes step-by-step instructions.</p></div>';
  panel.innerHTML = h;
}

/* ---------- device / mode / full screen ---------- */
$$('[data-dev]').forEach(function (b) {
  b.addEventListener('click', function () {
    canvas.dataset.dev = b.dataset.dev;
    $$('[data-dev]').forEach(function (o) { o.setAttribute('aria-pressed', o === b); });
  });
});
$$('[data-mode]').forEach(function (b) {
  b.addEventListener('click', function () {
    mode = b.dataset.mode;
    $$('[data-mode]').forEach(function (o) { o.setAttribute('aria-pressed', o === b); });
    if (mode === 'preview') {
      select(null);
      setStatus('Building preview…');
      previewHtml().then(function (html) {
        if (mode !== 'preview') return;
        pframe.srcdoc = html; pframe.hidden = false; frame.hidden = true; setStatus('Preview: links and buttons work here');
      }, function (er) { console.error('preview', er); setStatus('Preview couldn’t be built'); });
    } else { pframe.hidden = true; frame.hidden = false; pframe.srcdoc = ''; }
  });
});
var dataCache = {};
function dataUrl(path) {
  if (dataCache[path]) return dataCache[path];
  var b = fileBlob(path);
  if (!b) return Promise.resolve(null);
  dataCache[path] = new Promise(function (ok) {
    var r = new FileReader();
    r.onload = function () { ok(r.result); };
    r.onerror = function () { ok(null); };
    r.readAsDataURL(b);
  });
  return dataCache[path];
}
function replaceAsync(str, re, fn) {
  var jobs = [];
  str.replace(re, function () { jobs.push(fn.apply(null, arguments)); return ''; });
  return Promise.all(jobs).then(function (res) { var i = 0; return str.replace(re, function () { return res[i++]; }); });
}
var CSS_URL = /url\(\s*(['"]?)([^'")]+)\1\s*\)/g;
function cssToData(css, owner) {
  return replaceAsync(css, CSS_URL, function (m, q, ref) {
    if (isExternal(ref) || /^data:/i.test(ref)) return Promise.resolve(m);
    return dataUrl(resolve(owner, ref)).then(function (u) { return u ? 'url(' + q + u + q + ')' : m; });
  });
}
/* Preview runs in a sandbox with no access to this site, so images and fonts are embedded as data: URLs. */
function previewHtml() {
  var files = exportFiles(), d = new DOMParser().parseFromString(files[P.entry].text, 'text/html'), jobs = [];
  $$('link[rel~="stylesheet"][href]', d).forEach(function (l) {
    var href = l.getAttribute('href'); if (isExternal(href)) return;
    var path = resolve(P.entry, href), f = files[path]; if (!f || f.text == null) return;
    var s = d.createElement('style'); l.parentNode.replaceChild(s, l);
    jobs.push(cssToData(f.text, path).then(function (css) { s.textContent = css; }));
  });
  $$('script[src]', d).forEach(function (sc) {
    var src = sc.getAttribute('src'); if (isExternal(src)) return;
    var f = files[resolve(P.entry, src)]; if (!f || f.text == null) return;
    var n = d.createElement('script'); n.textContent = f.text.replace(/<\/script/gi, '<\\/script'); sc.parentNode.replaceChild(n, sc);
  });
  $$('img[srcset],source[srcset]', d).forEach(function (el) { el.removeAttribute('srcset'); });
  // In-page links (#about) and outside links behave like on the real site.
  var nav = d.createElement('script');
  nav.textContent = 'document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("a[href]");if(!a||e.defaultPrevented)return;var h=a.getAttribute("href");if(h.charAt(0)==="#"){e.preventDefault();if(h.length>1){if(location.hash!==h)location.hash=h;var t=document.getElementById(h.slice(1));if(t)t.scrollIntoView()}}else if(/^(https?:|mailto:|tel:)/i.test(h)){a.target="_blank";a.rel="noopener"}});';
  (d.body || d.documentElement).insertBefore(nav, (d.body || d.documentElement).firstChild);
  return Promise.all(jobs).then(function () {
    var html = '<!doctype html>\n' + d.documentElement.outerHTML;
    return replaceAsync(html, /(\s(?:src|poster)=")([^"]+)"/g, function (m, pre, ref) {
      if (isExternal(ref) || /^data:/i.test(ref)) return Promise.resolve(m);
      return dataUrl(resolve(P.entry, ref.replace(/&amp;/g, '&'))).then(function (u) { return u ? pre + u + '"' : m; });
    });
  }).then(function (html) { return cssToData(html, P.entry); });
}
var fullBtn = $('#bldFull');
fullBtn.addEventListener('click', function () {
  var on = !root.classList.contains('is-full');
  root.classList.toggle('is-full', on); document.body.classList.toggle('bld-lock', on);
  fullBtn.textContent = on ? 'Exit full screen' : 'Full screen';
});
undoBtn.addEventListener('click', undo);
redoBtn.addEventListener('click', redo);
$('#bldNew').addEventListener('click', function () {
  if (!confirm('Start over? Your current site will be removed from this browser. Download it first if you want to keep it.')) return;
  idb('del').catch(function () {});
  P = null; doc = null; frame.srcdoc = ''; app.hidden = true; start.hidden = false;
  if (root.classList.contains('is-full')) fullBtn.click();
  $('#bldResume').hidden = true;
});

/* ---------- start screen ---------- */
var tpls = $('#bldTpls'), startErr = $('#bldStartErr');
function startError(m) { startErr.textContent = m; startErr.hidden = !m; }
(C.templates || []).forEach(function (t) {
  var b = document.createElement('button');
  b.type = 'button'; b.className = 'bld-tpl';
  b.innerHTML = '<div class="cv ' + esc(t.cv || 'cv-honey') + '"></div><b>' + esc(t.name) + '</b><span>' + esc(t.desc) + '</span>';
  b.addEventListener('click', function () {
    b.disabled = true; startError('');
    Promise.all(t.files.map(function (f) {
      return fetch(t.base + f, { cache: 'no-cache' }).then(function (r) { if (!r.ok) throw new Error(f); return r.text(); });
    })).then(function (texts) {
      var files = {}; t.files.forEach(function (f, i) { files[f] = { text: texts[i] }; });
      open({ name: t.name, template: t.id, entry: 'index.html', files: files });
    }).catch(function () { startError('The template couldn’t be loaded. Check your connection and try again.'); })
      .then(function () { b.disabled = false; });
  });
  tpls.appendChild(b);
});

$('#bldUpload').addEventListener('change', function (e) {
  var f = e.target.files && e.target.files[0]; e.target.value = ''; startError('');
  if (!f) return;
  if (f.size > 40 * 1024 * 1024) return startError('That file is over 40 MB. Remove large videos or images and try again.');
  if (/\.html?$/i.test(f.name)) {
    f.text().then(function (txt) { open({ name: f.name, template: 'upload', entry: 'index.html', files: { 'index.html': { text: txt } } }); });
    return;
  }
  JSZip.loadAsync(f).then(function (zip) {
    var names = Object.keys(zip.files).filter(function (n) { return !zip.files[n].dir && !/(^|\/)(__MACOSX|\.DS_Store|Thumbs\.db)/.test(n); });
    if (!names.length) throw new Error('empty');
    var tops = names.map(function (n) { return n.split('/')[0]; }), pre = '';
    if (names.every(function (n) { return n.indexOf('/') > 0; }) && tops.every(function (t) { return t === tops[0]; })) pre = tops[0] + '/';
    return Promise.all(names.map(function (n) {
      var isText = TEXT_EXT.test(n);
      return zip.files[n].async(isText ? 'string' : 'blob').then(function (d) {
        var key = n.slice(pre.length);
        return [key, isText ? { text: d } : { blob: new Blob([d], { type: MIME[ext(n)] || 'application/octet-stream' }) }];
      });
    }));
  }).then(function (pairs) {
    var files = {}; pairs.forEach(function (p) { files[p[0]] = p[1]; });
    var htmls = Object.keys(files).filter(function (n) { return /\.html?$/i.test(n); })
      .sort(function (a, b) { return a.split('/').length - b.split('/').length || (/index\.html?$/i.test(b) - /index\.html?$/i.test(a)); });
    var entry = htmls.filter(function (n) { return /(^|\/)index\.html?$/i.test(n); })[0] || htmls[0];
    if (!entry) throw new Error('nohtml');
    open({ name: f.name.replace(/\.zip$/i, ''), template: 'upload', entry: entry, files: files });
  }).catch(function (err) {
    startError(err && err.message === 'nohtml' ? 'No .html file was found in that .zip. Your site needs an index.html.' : 'That file couldn’t be opened. Upload a .zip of your website folder or a single .html file.');
  });
});

function open(project) {
  P = project; uploadN = 0; dataCache = {};
  start.hidden = true; app.hidden = false;
  mode = 'edit'; pframe.hidden = true; frame.hidden = false;
  $$('[data-mode]').forEach(function (o) { o.setAttribute('aria-pressed', o.dataset.mode === 'edit'); });
  setTab('el');
  setStatus('Loading…');
  loadIntoFrame(function () { save(); });
  window.scrollTo(0, 0);
}

idb('get').then(function (p) {
  if (!p || !p.files || !p.entry || !p.files[p.entry]) return;
  $('#bldResume').hidden = false;
  $('#bldResumeInfo').textContent = (p.name || 'Your site') + (p.savedAt ? ' · last saved ' + new Date(p.savedAt).toLocaleString() : '');
  $('#bldResumeBtn').onclick = function () { open(p); };
}).catch(function () {});

/* ---------- download (email first) ---------- */
var EMAIL_KEY = 'br-builder-email';
function knownEmail() { try { return localStorage.getItem(EMAIL_KEY) || ''; } catch (e) { return ''; } }
$('#bldDownload').addEventListener('click', function () {
  if (!P) return;
  var err = $('#bldDlgErr'); err.hidden = true;
  $('#bldEmail').value = knownEmail();
  if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
  setTimeout(function () { $('#bldEmail').focus(); }, 30);
});
$('#bldDlgCancel').addEventListener('click', function () { dlg.close ? dlg.close() : dlg.removeAttribute('open'); });
$('#bldDlgForm').addEventListener('submit', function (e) {
  e.preventDefault();
  var email = $('#bldEmail').value.trim(), err = $('#bldDlgErr'), go = $('#bldDlgGo');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { err.textContent = 'Enter a valid email address, like name@gmail.com.'; err.hidden = false; return; }
  err.hidden = true; go.disabled = true; go.textContent = 'Preparing…';
  fetch(C.lead, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin',
    body: JSON.stringify({ email: email, template: P.template || '', website: e.target.website.value })
  }).then(function (r) {
    return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) throw new Error(j && j.message || 'save'); return j; });
  }).then(function () {
    try { localStorage.setItem(EMAIL_KEY, email); } catch (x) {}
    return download();
  }).then(function () {
    dlg.close ? dlg.close() : dlg.removeAttribute('open');
  }).catch(function (x) {
    err.textContent = x && x.message && x.message !== 'save' && x.message !== 'Failed to fetch' ? x.message : 'Your email couldn’t be saved, so the download didn’t start. Check your connection and try again.';
    err.hidden = false;
  }).then(function () { go.disabled = false; go.textContent = 'Download .zip'; });
});

function slug(s) { return (s || 'my-website').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'my-website'; }
var README = function (name) {
  return 'Your website: ' + name + '\r\n' +
    'Made with the free website builder on ' + (C.site || 'Bee Randomly') + '.\r\n\r\n' +
    'Everything in this folder is a normal static website. Open index.html in a browser to check it.\r\n\r\n' +
    'PUT IT ONLINE FOR FREE\r\n\r\n' +
    'Option A - Cloudflare Pages\r\n' +
    '1. Sign in at dash.cloudflare.com (a free account is enough).\r\n' +
    '2. Go to Workers & Pages, choose Create, then Pages, then Upload assets.\r\n' +
    '3. Give your project a name and upload this .zip file (or drag in the unzipped folder).\r\n' +
    '4. Click Deploy. Your site will be live at https://<project-name>.pages.dev\r\n\r\n' +
    'Option B - Vercel\r\n' +
    '1. Unzip this file.\r\n' +
    '2. Install Node.js from nodejs.org, then open a terminal in the unzipped folder.\r\n' +
    '3. Run:  npx vercel --prod\r\n' +
    '4. Sign in when asked and accept the defaults. Vercel gives you a https://<name>.vercel.app link.\r\n' +
    '   (Or put the folder in a GitHub repository and import it at vercel.com/new.)\r\n\r\n' +
    'CONTACT FORMS\r\n' +
    'Static hosting can\'t receive form messages by itself. Create a free form at formspree.io,\r\n' +
    'then in the builder select your form and paste the Formspree link into "Send form to" and set Method to POST.\r\n\r\n' +
    'TO EDIT AGAIN LATER\r\n' +
    'Open the website builder, choose "Upload your own site" and upload this .zip.\r\n';
};
function download() {
  P.files = exportFiles();
  var zip = new JSZip(), title = (doc && doc.querySelector('title') ? doc.querySelector('title').textContent : '') || P.name;
  Object.keys(P.files).forEach(function (k) {
    var f = P.files[k];
    if (/^README-DEPLOY\.txt$/i.test(k)) return;
    zip.file(k, f.text != null ? f.text : f.blob);
  });
  zip.file('README-DEPLOY.txt', README(title));
  return zip.generateAsync({ type: 'blob', compression: 'DEFLATE' }).then(function (blob) {
    var a = document.createElement('a'), u = URL.createObjectURL(blob);
    a.href = u; a.download = slug(title) + '.zip';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(u); }, 4000);
    setStatus('Downloaded ' + a.download);
    idb('put', P).catch(function () {});
  });
}

window.addEventListener('beforeunload', function () { if (P && doc) { clearTimeout(saveT); try { save(); } catch (e) {} } });
})();
