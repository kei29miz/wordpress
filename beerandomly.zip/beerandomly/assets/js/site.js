(function(){
var B=window.BR||{posts:[],i18n:{}},T=B.i18n||{};
var $=function(s){return document.querySelector(s)},$$=function(s){return [].slice.call(document.querySelectorAll(s))};
function toast(m){var t=$('#toast');if(!t)return;t.textContent=m;t.classList.add('show');clearTimeout(t._h);t._h=setTimeout(function(){t.classList.remove('show')},2200)}
function theme(){var r=document.documentElement,d=r.dataset.theme?r.dataset.theme==='dark':matchMedia('(prefers-color-scheme: dark)').matches,n=d?'light':'dark';r.dataset.theme=n;try{localStorage.setItem('br-theme',n)}catch(e){}}
function norm(u){try{return new URL(u,location.href).pathname.replace(/\/+$/,'')}catch(e){return u}}
document.addEventListener('click',function(e){
 var sh=e.target.closest('[data-share]');
 if(sh){e.preventDefault();e.stopPropagation();var url=new URL(sh.dataset.share,location.href).href,title=sh.dataset.title||document.title;
  if(navigator.share){navigator.share({title:title,url:url}).catch(function(){});return}
  if(navigator.clipboard){navigator.clipboard.writeText(url).then(function(){toast(T.copied||'Link copied')},function(){prompt(T.prompt||'Copy this link',url)})}else{prompt(T.prompt||'Copy this link',url)}return}
 if(e.target.closest('[data-theme-toggle]')){theme();return}
 if(e.target.closest('[data-back]')){var r=document.referrer;if(r&&r.indexOf(location.origin)===0&&history.length>1){e.preventDefault();history.back()}return}
 if(e.target.closest('[data-random]')){e.preventDefault();var here=norm(location.href),pool=(B.posts||[]).filter(function(u){return norm(u)!==here});
  if(pool.length)location.href=pool[Math.floor(Math.random()*pool.length)];else toast(T.nothing||'Nothing to land on yet');return}
 var card=e.target.closest('[data-open]');if(card&&!e.target.closest('a,button'))location.href=card.dataset.open;
});
document.addEventListener('keydown',function(e){if(e.key==='Enter'&&e.target.matches&&e.target.matches('[data-open]'))location.href=e.target.dataset.open});
/* Explore instant search */
var list=$('#exList');
if(list){var qs=new URLSearchParams(location.search),inp=$('#exQ'),label=$('#exLabel'),def=$('#exDefault'),res=$('#exResults'),cards=$$('#exList [data-search]');
 inp.value=qs.get('q')||'';var topic=qs.get('topic');
 var run=function(){var q=inp.value.trim().toLowerCase(),words=q.split(/\s+/).filter(Boolean),on=!!(q||topic);def.hidden=on;res.hidden=!on;if(!on)return;var n=0;
  cards.forEach(function(c){var s=c.dataset.search||'',tags=(c.dataset.tags||'').split(','),ok=(!topic||tags.indexOf(topic)>-1)&&words.every(function(w){return s.indexOf(w)>-1});c.hidden=!ok;if(ok)n++});
  label.textContent=(topic?'#'+topic:'')+(topic&&q?' matching ':'')+(q?'“'+inp.value.trim()+'”':'');$('#exNone').hidden=n>0};
 inp.addEventListener('input',function(){topic=null;history.replaceState(null,'',inp.value?'?q='+encodeURIComponent(inp.value):location.pathname);run()});
 $('#exClear').addEventListener('click',function(){inp.value='';topic=null;history.replaceState(null,'',location.pathname);run();inp.focus()});
 run();}
/* Blog sort */
$$('[data-bsort]').forEach(function(b){b.addEventListener('click',function(){var box=$('#blogList');if(!box)return;var k=b.dataset.bsort;
 [].slice.call(box.children).sort(function(a,c){return k==='quick'?a.dataset.words-c.dataset.words:c.dataset.date-a.dataset.date}).forEach(function(x){box.appendChild(x)});
 $$('[data-bsort]').forEach(function(o){o.setAttribute('aria-pressed',o===b)})})});
/* Home tabs */
$$('[data-ftab]').forEach(function(b){b.addEventListener('click',function(){var k=b.dataset.ftab;$$('[data-ftab]').forEach(function(o){o.setAttribute('aria-selected',o===b)});
 $$('#feed [data-type]').forEach(function(c){c.hidden=k!=='all'&&c.dataset.type!==k})})});
/* Reading bar */
var bar=$('#readBar'),art=$('#detail');
if(bar&&art){var f=function(){var r=art.getBoundingClientRect(),t=r.height-innerHeight;bar.style.width=(t>0?Math.min(1,Math.max(0,-r.top/t)):1)*100+'%'};addEventListener('scroll',f,{passive:true});f()}
/* Share networks + copy */
var u=encodeURIComponent(location.href),ti=encodeURIComponent(document.title),N={whatsapp:'https://wa.me/?text='+ti+'%20'+u,x:'https://twitter.com/intent/tweet?text='+ti+'&url='+u,facebook:'https://www.facebook.com/sharer/sharer.php?u='+u};
$$('[data-net]').forEach(function(a){a.href=N[a.dataset.net]});
$$('[data-copy]').forEach(function(b){b.addEventListener('click',function(){var done=function(){b.textContent=T.copiedB||'Copied ✓';setTimeout(function(){b.textContent=T.copy||'Copy link'},1800)};
 if(navigator.clipboard)navigator.clipboard.writeText(location.href).then(done,function(){prompt(T.prompt||'Copy this link',location.href)});else prompt(T.prompt||'Copy this link',location.href)})});
})();
