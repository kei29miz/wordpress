(function () {
  "use strict";

  // ---- footer year ----
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // ---- mobile nav toggle ----
  var navToggle = document.getElementById("navToggle");
  var siteNav = document.getElementById("siteNav");

  if (navToggle && siteNav) {
    navToggle.addEventListener("click", function () {
      var isOpen = siteNav.classList.toggle("is-open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    siteNav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        siteNav.classList.remove("is-open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  // ---- theme toggle (persisted per-browser only) ----
  var themeToggle = document.getElementById("themeToggle");
  var root = document.documentElement;

  function applyStoredTheme() {
    try {
      var stored = localStorage.getItem("rc-theme");
      if (stored === "dark" || stored === "light") {
        root.setAttribute("data-theme", stored);
      }
    } catch (e) {
      /* storage unavailable (private mode, etc.) — fall back to system theme */
    }
  }
  applyStoredTheme();

  if (themeToggle) {
    themeToggle.addEventListener("click", function () {
      var current = root.getAttribute("data-theme");
      var prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
      var effectiveDark = current === "dark" || (!current && prefersDark);
      var next = effectiveDark ? "light" : "dark";
      root.setAttribute("data-theme", next);
      try {
        localStorage.setItem("rc-theme", next);
      } catch (e) {
        /* ignore */
      }
    });
  }

  // ---- copy email button ----
  var copyBtn = document.getElementById("copyEmailBtn");
  var emailText = document.getElementById("emailText");

  if (copyBtn && emailText) {
    copyBtn.addEventListener("click", function () {
      var text = emailText.textContent.trim();
      var originalLabel = copyBtn.textContent;

      function showCopied() {
        copyBtn.textContent = "Copied!";
        setTimeout(function () {
          copyBtn.textContent = originalLabel;
        }, 1800);
      }

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(showCopied, function () {
          fallbackSelect();
        });
      } else {
        fallbackSelect();
      }

      function fallbackSelect() {
        var range = document.createRange();
        range.selectNode(emailText);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        showCopied();
      }
    });
  }

  // ---- contact form (demo only — not wired to a server) ----
  var form = document.getElementById("contactForm");
  var formNote = document.getElementById("formNote");

  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (formNote) formNote.hidden = false;
      form.reset();
    });
  }

  // ---- hash router (only active on the single-file preview build,
  // which marks each "page" with data-page; the real multi-file site
  // has no such elements and this block does nothing there) ----
  var pages = document.querySelectorAll(".page[data-page]");

  if (pages.length) {
    var navLinks = document.querySelectorAll("[data-nav-link]");

    function route() {
      var hash = (location.hash || "#home").slice(1);
      var found = false;

      pages.forEach(function (p) {
        var match = p.getAttribute("data-page") === hash;
        p.hidden = !match;
        if (match) found = true;
      });

      if (!found) {
        pages.forEach(function (p) {
          p.hidden = p.getAttribute("data-page") !== "home";
        });
      }

      navLinks.forEach(function (a) {
        var key = a.getAttribute("data-nav-link");
        var active = key === hash || (hash.indexOf("case-") === 0 && key === "work");
        a.classList.toggle("is-current", active);
      });

      window.scrollTo(0, 0);
    }

    window.addEventListener("hashchange", route);
    route();
  }
})();
