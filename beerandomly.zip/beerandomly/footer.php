<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?></main>
<?php get_sidebar(); ?></div>
<nav class="bottombar" aria-label="Main"><?php
$act = br_active();
foreach ( br_nav_items() as $k => $it ) {
	echo '<a href="' . esc_url( $it[0] ) . '"' . ( $act === $k ? ' aria-current="page"' : '' ) . '>' . br_icon( $k ) . '<span>' . esc_html( $it[2] ) . '</span></a>'; // phpcs:ignore
}
?></nav><div class="toast" id="toast" role="status"></div>
<?php wp_footer(); ?></body></html>
