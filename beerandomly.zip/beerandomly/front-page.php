<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
br_topbar( br_name() );
$feat = br_featured();
?>
<div class="stack"><section class="card mini"><div class="cv cv-honey"><div style="height:64px"></div></div><div class="mini-body"><?php echo br_avatar(); // phpcs:ignore ?><div class="mini-id"><div class="nm"><?php echo esc_html( br_name() ); ?></div><div class="sub">🐝 <?php echo esc_html( br_tagline() ); ?></div></div><a class="btn btn-outline" href="<?php echo esc_url( br_page_url( 'about' ) ); ?>"><?php esc_html_e( 'About', 'beerandomly' ); ?></a></div><p><?php echo esc_html( br_bio() ); ?></p></section>
<?php if ( $feat ) { br_featured_card( $feat ); } ?>
<section class="card feed"><h2 class="sr-only"><?php esc_html_e( 'Latest guides and tips', 'beerandomly' ); ?></h2><div class="tabs" role="tablist"><button class="tab" role="tab" data-ftab="all" aria-selected="true"><?php esc_html_e( 'Latest', 'beerandomly' ); ?></button><button class="tab" role="tab" data-ftab="post" aria-selected="false"><?php esc_html_e( 'Guides', 'beerandomly' ); ?></button><button class="tab" role="tab" data-ftab="thought" aria-selected="false"><?php esc_html_e( 'Quick tips', 'beerandomly' ); ?></button></div><div id="feed"><?php
$posts = br_posts( 'all', 30, $feat ? array( $feat->ID ) : array() );
foreach ( $posts as $p ) { br_acard( $p ); }
if ( ! $posts ) { echo '<div class="empty"><h2>' . esc_html__( 'Nothing here yet', 'beerandomly' ) . '</h2></div>'; }
?></div></section></div>
<?php get_footer();
