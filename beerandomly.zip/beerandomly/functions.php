<?php
/**
 * Bee Randomly — theme bootstrap.
 *
 * @package beerandomly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BR_VERSION', '3.2.0' );

require get_template_directory() . '/inc/helpers.php';
require get_template_directory() . '/inc/cards.php';
require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/seo.php';
require get_template_directory() . '/inc/redirects.php';
require get_template_directory() . '/inc/admin.php';
require get_template_directory() . '/inc/tools.php';
