<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?><!doctype html>
<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); get_template_part( 'template-parts/sprite' ); ?><a class="sr-only skip-link" href="#main"><?php esc_html_e( 'Skip to content', 'beerandomly' ); ?></a><div id="readBar" aria-hidden="true"></div>
<header class="masthead"><a class="mh-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( br_name() ); ?> — home"><svg viewBox="0 0 64 64" aria-hidden="true"><use href="#logo"/></svg><span class="mh-name"><?php echo esc_html( br_name() ); ?></span></a><p class="mh-tag"><?php echo esc_html( br_tagline() ); ?></p></header>
<div class="shell">
<nav class="left" aria-label="Main"><?php
$act = br_active();
foreach ( br_nav_items() as $k => $it ) {
	echo '<a class="nav-btn" href="' . esc_url( $it[0] ) . '"' . ( $act === $k ? ' aria-current="page"' : '' ) . '>' . br_icon( $k ) . '<span>' . esc_html( $it[1] ) . '</span></a>'; // phpcs:ignore
}
?>
<a class="nav-btn" href="#" data-random><?php echo br_icon( 'random' ); // phpcs:ignore ?><span><?php esc_html_e( 'Random', 'beerandomly' ); ?></span></a><div class="spacer"></div><button class="nav-btn" data-theme-toggle><?php echo br_icon( 'moon' ); // phpcs:ignore ?><span><?php esc_html_e( 'Theme', 'beerandomly' ); ?></span></button>
<div class="tally" aria-hidden="true"><span class="tally-n"><?php echo (int) br_count(); ?></span> <?php esc_html_e( 'entries on the books', 'beerandomly' ); ?></div></nav>
<main class="center" id="main">
