<?php
/**
 * "Bee Randomly display" box in the post editor.
 *
 * @package beerandomly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'add_meta_boxes',
	function () {
		add_meta_box( 'br_display', __( 'Bee Randomly display', 'beerandomly' ), 'br_meta_box', 'post', 'side', 'default' );
	}
);

function br_meta_box( $post ) {
	wp_nonce_field( 'br_meta', 'br_meta_nonce' );
	$type  = br_is_thought( $post ) ? 'thought' : 'article';
	$f     = function ( $k ) use ( $post ) {
		return (string) get_post_meta( $post->ID, '_br_' . $k, true );
	};
	$cvs   = array( '' => 'Auto', 'cv-honey' => 'Honey', 'cv-lavender' => 'Lavender', 'cv-meadow' => 'Meadow', 'cv-dusk' => 'Dusk', 'cv-night' => 'Night' );
	$tcs   = array( '' => 'Auto', 'tc-lavender' => 'Lavender', 'tc-honey' => 'Honey', 'tc-meadow' => 'Meadow', 'tc-rose' => 'Rose', 'tc-night' => 'Night', 'tc-plain' => 'Plain' );
	?>
	<p><label><strong><?php esc_html_e( 'Type', 'beerandomly' ); ?></strong><br>
	<select name="br_type" style="width:100%">
		<option value="article" <?php selected( $type, 'article' ); ?>><?php esc_html_e( 'Article (blog post)', 'beerandomly' ); ?></option>
		<option value="thought" <?php selected( $type, 'thought' ); ?>><?php esc_html_e( 'Thought (one-liner)', 'beerandomly' ); ?></option>
	</select></label></p>
	<p class="description"><?php esc_html_e( 'Cover image = Featured image. Featured story on the home page = “Stick to the top of the blog”.', 'beerandomly' ); ?></p>
	<p><label><?php esc_html_e( 'Cover focus (e.g. 50% 18%)', 'beerandomly' ); ?><br><input type="text" name="br_pos" value="<?php echo esc_attr( $f( 'pos' ) ); ?>" style="width:100%"></label></p>
	<p><label><?php esc_html_e( 'Image credit text', 'beerandomly' ); ?><br><input type="text" name="br_credit" value="<?php echo esc_attr( $f( 'credit' ) ); ?>" style="width:100%"></label></p>
	<p><label><?php esc_html_e( 'Image credit link', 'beerandomly' ); ?><br><input type="url" name="br_credit_url" value="<?php echo esc_attr( $f( 'credit_url' ) ); ?>" style="width:100%"></label></p>
	<p><label><?php esc_html_e( 'Colour when there is no image', 'beerandomly' ); ?><br><select name="br_cv" style="width:100%">
	<?php foreach ( $cvs as $k => $v ) : ?>
		<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $f( 'cv' ), $k ); ?>><?php echo esc_html( $v ); ?></option>
	<?php endforeach; ?></select></label></p>
	<p><label><?php esc_html_e( 'Thought panel colour', 'beerandomly' ); ?><br><select name="br_tc" style="width:100%">
	<?php foreach ( $tcs as $k => $v ) : ?>
		<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $f( 'tc' ), $k ); ?>><?php echo esc_html( $v ); ?></option>
	<?php endforeach; ?></select></label></p>
	<?php
}

add_action(
	'save_post_post',
	function ( $post_id ) {
		if ( ! isset( $_POST['br_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['br_meta_nonce'] ) ), 'br_meta' ) ) {
			return;
		}
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		foreach ( array( 'pos', 'credit', 'cv', 'tc' ) as $k ) {
			$v = isset( $_POST[ 'br_' . $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ 'br_' . $k ] ) ) : '';
			$v ? update_post_meta( $post_id, '_br_' . $k, $v ) : delete_post_meta( $post_id, '_br_' . $k );
		}
		$u = isset( $_POST['br_credit_url'] ) ? esc_url_raw( wp_unslash( $_POST['br_credit_url'] ) ) : '';
		$u ? update_post_meta( $post_id, '_br_credit_url', $u ) : delete_post_meta( $post_id, '_br_credit_url' );

		$type = ( isset( $_POST['br_type'] ) && 'thought' === $_POST['br_type'] ) ? 'thought' : 'article';
		update_post_meta( $post_id, '_br_type', $type );
		$tid = br_thoughts_term_id();
		if ( $tid ) {
			if ( 'thought' === $type ) {
				wp_set_post_categories( $post_id, array( $tid ), true );
			} else {
				$cats = array_diff( wp_get_post_categories( $post_id ), array( $tid ) );
				wp_set_post_categories( $post_id, $cats ? $cats : array( (int) get_option( 'default_category' ) ), false );
			}
		}
	}
);
