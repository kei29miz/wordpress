<?php
/**
 * Reusable markup: cards, page heads, share box, author box.
 * Markup mirrors the original static site class-for-class so style.css applies unchanged.
 *
 * @package beerandomly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Text used by Explore's instant search. */
function br_search_blob( $post ) {
	$names = wp_list_pluck( br_tags( $post ), 'name' );
	$blob  = br_title( $post ) . ' ' . br_excerpt( $post, false ) . ' ' . br_text( $post ) . ' ' . implode( ' ', $names );
	return mb_strtolower( trim( preg_replace( '/\s+/u', ' ', $blob ) ) );
}

/** Feed card (home, blog, explore, archives, "more from"). */
function br_acard( $post, $args = array() ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return;
	}
	$args    = wp_parse_args( $args, array( 'search' => false ) );
	$thought = br_is_thought( $post );
	$url     = get_permalink( $post );
	$title   = br_title( $post );
	$tags    = br_tags( $post );
	$cover   = $thought ? null : br_cover( $post );
	$attrs   = ' data-type="' . ( $thought ? 'thought' : 'post' ) . '" data-open="' . esc_url( $url ) . '"';
	$attrs  .= ' data-date="' . esc_attr( get_post_time( 'U', true, $post ) ) . '" data-words="' . esc_attr( br_words( $post ) ) . '"';
	if ( $args['search'] ) {
		$attrs .= ' data-search="' . esc_attr( br_search_blob( $post ) ) . '" data-tags="' . esc_attr( implode( ',', wp_list_pluck( $tags, 'slug' ) ) ) . '"';
	}
	?>
<article class="acard <?php echo $thought ? 'no-thumb' : ''; ?>"<?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput ?> tabindex="0">
<div><div class="byline"><?php echo br_avatar(); // phpcs:ignore WordPress.Security.EscapeOutput ?><span class="nm"><?php echo esc_html( br_name() ); ?></span><span><time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d', $post ) ); ?>"><?php echo esc_html( get_the_date( 'M j, Y', $post ) ); ?></time></span></div>
<div class="kicker <?php echo $thought ? 't' : ''; ?>"><span class="dot"></span><?php echo $thought ? esc_html__( 'Quick tip', 'beerandomly' ) : esc_html__( 'Guide', 'beerandomly' ); ?></div>
<h3 class="a-title <?php echo $thought ? 'is-thought' : ''; ?>"><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $title ); ?></a></h3><?php
	if ( ! $thought ) {
		$ex = br_excerpt( $post );
		if ( $ex ) {
			echo '<p class="a-ex">' . esc_html( $ex ) . '</p>';
		}
	}
	?>

<div class="a-foot"><span><?php echo esc_html( br_read_label( $post ) ); ?></span><?php echo $tags ? br_tag_link( $tags[0] ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput ?><span class="grow"></span><div class="a-acts"><?php echo br_share_btn( $url, br_short( $title, 50 ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div></div></div><?php
	if ( ! $thought ) {
		if ( $cover ) {
			echo '<div class="a-thumb">' . br_cover_img( $cover, array( 'loading' => 'lazy', 'decoding' => 'async' ) ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		} else {
			$letter = mb_strtoupper( mb_substr( preg_replace( '/^[^\p{L}\p{N}]+/u', '', $title ), 0, 1 ) );
			echo '<div class="a-thumb cv ' . esc_attr( br_cv_class( $post ) ) . '" aria-hidden="true"><b>' . esc_html( $letter ) . '</b></div>';
		}
	}
	?></article>
	<?php
}

/** Thought tile (Thoughts page). */
function br_tcard( $post ) {
	$post = get_post( $post );
	$url  = get_permalink( $post );
	$text = br_text( $post );
	if ( '' === $text ) {
		$text = br_title( $post );
	}
	?>
<article class="tcard" data-open="<?php echo esc_url( $url ); ?>" tabindex="0"><p class="tq"><a href="<?php echo esc_url( $url ); ?>" class="a-link"><?php echo esc_html( $text ); ?></a></p>
<div class="tmeta"><time datetime="<?php echo esc_attr( get_the_date( 'Y-m-d', $post ) ); ?>"><?php echo esc_html( get_the_date( 'M j, Y', $post ) ); ?></time></div><div class="tags"><?php
	foreach ( br_tags( $post ) as $t ) {
		echo br_tag_link( $t ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
	?></div><div class="actions"><?php echo br_share_btn( $url, br_short( br_title( $post ), 50 ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div></article>
	<?php
}

/** Big "Featured story" card on the home page. */
function br_featured_card( $post ) {
	$post  = get_post( $post );
	$url   = get_permalink( $post );
	$title = br_title( $post );
	$cover = br_cover( $post );
	echo '<article class="card bcard" data-open="' . esc_url( $url ) . '" tabindex="0">';
	if ( $cover ) {
		echo '<div class="bband" style="height:220px">' . br_cover_img( $cover, array( 'fetchpriority' => 'high' ) ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	} else {
		echo '<div class="bband cv ' . esc_attr( br_cv_class( $post ) ) . '" style="height:220px" aria-hidden="true"></div>';
	}
	echo '<div class="bbody feature"><h2 class="sr-only">' . esc_html__( 'Featured guide', 'beerandomly' ) . '</h2><div class="kicker" aria-hidden="true"><span class="dot"></span>' . esc_html__( 'Featured guide', 'beerandomly' ) . '</div>';
	echo '<div class="bmeta"><span><time datetime="' . esc_attr( get_the_date( 'Y-m-d', $post ) ) . '">' . esc_html( get_the_date( 'F j, Y', $post ) ) . '</time></span><span>' . esc_html( br_read_label( $post ) ) . '</span></div>';
	echo '<h3><a href="' . esc_url( $url ) . '">' . esc_html( $title ) . '</a></h3>';
	$ex = br_excerpt( $post );
	if ( $ex ) {
		echo '<p class="bex">' . esc_html( $ex ) . '</p>';
	}
	$tags = array_slice( br_tags( $post ), 0, 3 );
	if ( $tags ) {
		echo '<div class="tags">';
		foreach ( $tags as $t ) {
			echo br_tag_link( $t ); // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';
	}
	echo '<div class="actions">' . br_share_btn( $url, $title ) . '</div></div></article>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

/** Header card used on Blog, Thoughts, tag archives, search. */
function br_page_head( $title, $sub, $icon = 'blog', $cv = 'cv-honey', $tag = 'p' ) {
	$tag = ( 'h1' === $tag ) ? 'h1' : 'p';
	echo '<section class="card page-head"><div class="cv ' . esc_attr( $cv ) . '"><div class="ph-cover"></div></div><div class="ph-body"><div class="ph-icon">' . br_icon( $icon ) . '</div><div class="ph-text"><' . $tag . ' class="ph-title">' . esc_html( $title ) . '</' . $tag . '><p>' . esc_html( $sub ) . '</p></div></div></section>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

function br_share_box( $label ) {
	$url   = is_singular() ? get_permalink() : home_url( add_query_arg( array() ) );
	$title = is_singular() ? br_short( br_title(), 50 ) : wp_get_document_title();
	?>
<div class="share-box"><b><?php echo esc_html( $label ); ?></b><div class="share-btns"><button class="btn btn-primary" data-share="<?php echo esc_url( $url ); ?>" data-title="<?php echo esc_attr( $title ); ?>"><?php echo br_icon( 'share' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>&nbsp;<?php esc_html_e( 'Share', 'beerandomly' ); ?></button><button class="btn btn-outline" data-copy><?php esc_html_e( 'Copy link', 'beerandomly' ); ?></button><a class="btn btn-outline" data-net="whatsapp" href="#" target="_blank" rel="noopener">WhatsApp</a><a class="btn btn-outline" data-net="x" href="#" target="_blank" rel="noopener">X</a><a class="btn btn-outline" data-net="facebook" href="#" target="_blank" rel="noopener">Facebook</a></div></div>
	<?php
}

function br_author_box() {
	?>
<div class="author-box"><div class="pf-avatar"><?php echo br_bee_svg(); // phpcs:ignore WordPress.Security.EscapeOutput ?></div><div style="flex:1;min-width:0"><small><?php esc_html_e( 'Written by', 'beerandomly' ); ?></small><b><?php echo esc_html( br_name() ); ?></b><p><?php echo esc_html( br_bio() ); ?></p><a class="btn btn-outline" href="<?php echo esc_url( br_page_url( 'about' ) ); ?>"><?php esc_html_e( 'About', 'beerandomly' ); ?></a></div></div>
	<?php
}

/** "More from" list under a post or page. */
function br_more_from( $heading, $exclude = array(), $n = 3 ) {
	$posts = br_posts( 'article', $n, $exclude );
	if ( ! $posts ) {
		return;
	}
	echo '<section class="more-from"><div><h2>' . esc_html( $heading ) . '</h2>';
	foreach ( $posts as $p ) {
		br_acard( $p );
	}
	echo '</div></section>';
}

/** Search box (sidebar). Submits to Explore with ?q=. */
function br_search_form( $placeholder = '' ) {
	$placeholder = $placeholder ? $placeholder : sprintf( /* translators: site name */ __( 'Search %s', 'beerandomly' ), br_name() );
	echo '<form class="search" role="search" method="get" action="' . esc_url( br_page_url( 'explore' ) ) . '"><span>' . br_icon( 'explore' ) . '</span><input type="search" name="q" placeholder="' . esc_attr( $placeholder ) . '" aria-label="' . esc_attr__( 'Search', 'beerandomly' ) . '"></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
}
