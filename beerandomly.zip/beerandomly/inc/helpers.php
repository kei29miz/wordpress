<?php
/**
 * Helpers: names, URLs, icons, covers, word counts.
 *
 * @package beerandomly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const BR_DEFAULT_BIO     = 'Practical help for AI users and anyone who wants to earn with it. Beginner-friendly guides, honest tool reviews, prompts that work, and real ways to turn AI skills into income.';
const BR_DEFAULT_TAGLINE = 'Learn AI, use it well, and earn from it';

/* ---------- Site identity ---------- */

function br_name() {
	$n = get_bloginfo( 'name' );
	return $n ? $n : 'Bee Randomly';
}

function br_tagline() {
	$t = get_bloginfo( 'description' );
	return $t ? $t : BR_DEFAULT_TAGLINE;
}

function br_bio() {
	$b = get_theme_mod( 'br_bio', BR_DEFAULT_BIO );
	return $b ? $b : BR_DEFAULT_BIO;
}

function br_location() {
	return (string) get_theme_mod( 'br_location', 'Quezon City' );
}

/* ---------- Page URLs ---------- */

/**
 * Finds the page that uses one of our templates, falling back to a page with that slug.
 *
 * @param string $key explore|thoughts|blog|about|privacy.
 * @return WP_Post|null
 */
function br_page( $key ) {
	static $cache = array();
	if ( array_key_exists( $key, $cache ) ) {
		return $cache[ $key ];
	}
	$found = null;
	if ( in_array( $key, array( 'explore', 'thoughts', 'blog', 'tools', 'builder' ), true ) ) {
		$ids = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => 'template-' . $key . '.php', // phpcs:ignore WordPress.DB.SlowDBQuery
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		if ( $ids ) {
			$found = get_post( $ids[0] );
		}
	}
	if ( ! $found ) {
		$slugs = ( 'privacy' === $key ) ? array( 'privacy', 'privacy-policy' ) : ( 'builder' === $key ? array( 'website-builder', 'builder' ) : array( $key ) );
		foreach ( $slugs as $slug ) {
			$p = get_page_by_path( $slug );
			if ( $p && 'publish' === $p->post_status ) {
				$found = $p;
				break;
			}
		}
	}
	$cache[ $key ] = $found;
	return $found;
}

function br_page_url( $key ) {
	$p = br_page( $key );
	return $p ? get_permalink( $p ) : home_url( '/' . $key . '/' );
}

/** Explore page URL with a search term. */
function br_search_url( $q = '' ) {
	return $q ? add_query_arg( 'q', rawurlencode( $q ), br_page_url( 'explore' ) ) : br_page_url( 'explore' );
}

/* ---------- Icons / small bits ---------- */

function br_icon( $name ) {
	static $i = array(
		'home'     => '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>',
		'explore'  => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
		'thoughts' => '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V16h5.2v-.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"/>',
		'blog'     => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
		'about'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
		'random'   => '<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
		'moon'     => '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
		'share'    => '<path d="M12 3v13M7 8l5-5 5 5"/><path d="M5 13v6a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-6"/>',
		'back'     => '<path d="M19 12H5M12 19l-7-7 7-7"/>',
		'tools'    => '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.2L3 17.8V21h3.2l6.3-6.3a4 4 0 0 0 5.2-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
		'build'    => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M9 9v11"/>',
		'tag'      => '<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L3 13V3h10l7.6 7.6a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
	);
	$path = isset( $i[ $name ] ) ? $i[ $name ] : '';
	return '<svg class="i" viewBox="0 0 24 24" aria-hidden="true">' . $path . '</svg>';
}

function br_bee_svg() {
	return '<svg viewBox="-26 -22 46 36" aria-hidden="true"><use href="#bee" transform="rotate(-12)"/></svg>';
}

function br_avatar( $class = 'avatar ' ) {
	return '<div class="' . esc_attr( $class ) . '">' . br_bee_svg() . '</div>';
}

function br_share_btn( $url, $title ) {
	return '<button type="button" class="act" data-share="' . esc_url( $url ) . '" data-title="' . esc_attr( $title ) . '" aria-label="' . esc_attr__( 'Share', 'beerandomly' ) . '">' . br_icon( 'share' ) . '</button>';
}

function br_short( $text, $n = 50 ) {
	$text = trim( (string) $text );
	return mb_strlen( $text ) > $n ? rtrim( mb_substr( $text, 0, $n ) ) . '…' : $text;
}

/* ---------- Covermap (bundled covers for the original posts) ---------- */

function br_cover_map() {
	static $map = null;
	if ( null === $map ) {
		$file = get_theme_file_path( 'covermap.json' );
		$map  = file_exists( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! is_array( $map ) ) {
			$map = array();
		}
	}
	return $map;
}

/** One field for a post: post meta (set in the editor) wins over the bundled covermap. */
function br_opt( $post, $key ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return '';
	}
	$meta = get_post_meta( $post->ID, '_br_' . $key, true );
	if ( '' !== $meta && null !== $meta ) {
		return $meta;
	}
	$map = br_cover_map();
	return isset( $map[ $post->post_name ][ $key ] ) ? $map[ $post->post_name ][ $key ] : '';
}

/* ---------- Thoughts vs articles ---------- */

function br_thoughts_term_id() {
	$t = get_category_by_slug( 'thoughts' );
	return $t ? (int) $t->term_id : 0;
}

function br_is_thought( $post = null ) {
	$post = get_post( $post );
	if ( ! $post || 'post' !== $post->post_type ) {
		return false;
	}
	$type = get_post_meta( $post->ID, '_br_type', true );
	if ( 'thought' === $type ) {
		return true;
	}
	if ( 'article' === $type ) {
		return false;
	}
	if ( has_category( 'thoughts', $post ) ) {
		return true;
	}
	if ( in_array( get_post_format( $post ), array( 'quote', 'aside', 'status' ), true ) ) {
		return true;
	}
	$map = br_cover_map();
	return isset( $map[ $post->post_name ]['type'] ) && 'thought' === $map[ $post->post_name ]['type'];
}

/** IDs of every published thought (for excluding them from article lists). */
function br_thought_ids() {
	static $ids = null;
	if ( null === $ids ) {
		$ids = array();
		$all = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 500,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		foreach ( $all as $pid ) {
			if ( br_is_thought( $pid ) ) {
				$ids[] = (int) $pid;
			}
		}
	}
	return $ids;
}

/* ---------- Text, words, reading time ---------- */

function br_text( $post = null ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return '';
	}
	$t = wp_strip_all_tags( strip_shortcodes( excerpt_remove_blocks( $post->post_content ) ) );
	$t = html_entity_decode( $t, ENT_QUOTES, 'UTF-8' );
	return trim( preg_replace( '/\s+/u', ' ', $t ) );
}

function br_words( $post = null ) {
	$t = br_text( $post );
	return '' === $t ? 0 : count( preg_split( '/\s+/u', $t, -1, PREG_SPLIT_NO_EMPTY ) );
}

function br_minutes( $post = null ) {
	return max( 1, (int) round( br_words( $post ) / 225 ) );
}

function br_read_label( $post = null ) {
	if ( br_is_thought( $post ) ) {
		return __( 'Quick read', 'beerandomly' );
	}
	return br_minutes( $post ) . ' ' . __( 'min read', 'beerandomly' );
}

/** The display title. Thoughts with an empty title use their text. */
function br_title( $post = null ) {
	$post  = get_post( $post );
	$title = wp_strip_all_tags( get_the_title( $post ) );
	if ( '' === trim( $title ) ) {
		$title = br_short( br_text( $post ), 80 );
	}
	return $title;
}

/** Excerpt only if one was written (or a short auto one for articles in lists). */
function br_excerpt( $post = null, $auto = true ) {
	$post = get_post( $post );
	if ( has_excerpt( $post ) ) {
		return wp_strip_all_tags( $post->post_excerpt );
	}
	return $auto ? br_short( br_text( $post ), 160 ) : '';
}

function br_tags( $post = null ) {
	$t = get_the_tags( get_post( $post ) );
	return ( $t && ! is_wp_error( $t ) ) ? $t : array();
}

function br_tag_link( $tag ) {
	return '<a class="tag" href="' . esc_url( get_tag_link( $tag ) ) . '">#' . esc_html( $tag->name ) . '</a>';
}

/* ---------- Covers ---------- */

/**
 * Cover image for a post: featured image first, then the bundled cover.
 *
 * @return array|null url, alt, w, h, pos, credit, credit_url
 */
function br_cover( $post = null ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return null;
	}
	$pos        = (string) br_opt( $post, 'pos' );
	$credit     = (string) br_opt( $post, 'credit' );
	$credit_url = (string) br_opt( $post, 'credit_url' );

	if ( has_post_thumbnail( $post ) ) {
		$tid = get_post_thumbnail_id( $post );
		$src = wp_get_attachment_image_src( $tid, 'large' );
		if ( $src ) {
			return array(
				'id'         => $tid,
				'url'        => $src[0],
				'alt'        => (string) get_post_meta( $tid, '_wp_attachment_image_alt', true ),
				'w'          => (int) $src[1],
				'h'          => (int) $src[2],
				'pos'        => $pos,
				'credit'     => $credit,
				'credit_url' => $credit_url,
			);
		}
	}
	$map = br_cover_map();
	$m   = isset( $map[ $post->post_name ] ) ? $map[ $post->post_name ] : array();
	if ( ! empty( $m['file'] ) && file_exists( get_theme_file_path( 'assets/covers/' . $m['file'] . '.webp' ) ) ) {
		return array(
			'id'         => 0,
			'url'        => get_theme_file_uri( 'assets/covers/' . $m['file'] . '.webp' ),
			'alt'        => isset( $m['alt'] ) ? $m['alt'] : '',
			'w'          => isset( $m['w'] ) ? (int) $m['w'] : 1080,
			'h'          => isset( $m['h'] ) ? (int) $m['h'] : 720,
			'pos'        => $pos,
			'credit'     => $credit,
			'credit_url' => $credit_url,
		);
	}
	return null;
}

/** <img> tag for a cover. */
function br_cover_img( $c, $attrs = array() ) {
	$style = $c['pos'] ? ' style="object-position:' . esc_attr( $c['pos'] ) . '"' : '';
	$extra = '';
	foreach ( $attrs as $k => $v ) {
		$extra .= ' ' . $k . '="' . esc_attr( $v ) . '"';
	}
	return '<img src="' . esc_url( $c['url'] ) . '" alt="' . esc_attr( $c['alt'] ) . '" width="' . (int) $c['w'] . '" height="' . (int) $c['h'] . '"' . $style . $extra . '>';
}

function br_cv_class( $post = null ) {
	$post = get_post( $post );
	$cv   = (string) br_opt( $post, 'cv' );
	if ( $cv ) {
		return $cv;
	}
	$all = array( 'cv-honey', 'cv-lavender', 'cv-meadow', 'cv-dusk', 'cv-night' );
	return $all[ $post->ID % count( $all ) ];
}

function br_tc_class( $post = null ) {
	$post = get_post( $post );
	$tc   = (string) br_opt( $post, 'tc' );
	if ( $tc ) {
		return $tc;
	}
	$all = array( 'tc-lavender', 'tc-honey', 'tc-meadow', 'tc-rose' );
	return $all[ $post->ID % count( $all ) ];
}

function br_og_image( $post = null ) {
	$post = get_post( $post );
	if ( $post && has_post_thumbnail( $post ) ) {
		return get_the_post_thumbnail_url( $post, 'large' );
	}
	$og = $post ? (string) br_opt( $post, 'og' ) : '';
	if ( $og && file_exists( get_theme_file_path( 'assets/og/' . $og ) ) ) {
		return get_theme_file_uri( 'assets/og/' . $og );
	}
	return get_theme_file_uri( 'assets/og/og-default.png' );
}

/* ---------- Queries ---------- */

/**
 * Published posts.
 *
 * @param string $kind all|article|thought.
 * @param int    $n    How many (-1 = all, capped at 500).
 * @param array  $not  Post IDs to skip.
 * @return WP_Post[]
 */
function br_posts( $kind = 'all', $n = -1, $not = array() ) {
	$args = array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => ( $n < 0 ) ? 500 : $n,
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'post__not_in'        => array_map( 'intval', (array) $not ),
	);
	if ( 'article' === $kind ) {
		$args['post__not_in'] = array_merge( $args['post__not_in'], br_thought_ids() );
	} elseif ( 'thought' === $kind ) {
		$ids = br_thought_ids();
		if ( ! $ids ) {
			return array();
		}
		$args['post__in'] = $ids;
	}
	return get_posts( $args );
}

/** Featured story: newest sticky article, else the newest article. */
function br_featured() {
	$sticky = array_diff( array_map( 'intval', (array) get_option( 'sticky_posts', array() ) ), br_thought_ids() );
	if ( $sticky ) {
		$p = get_posts(
			array(
				'post__in'            => $sticky,
				'post_status'         => 'publish',
				'posts_per_page'      => 1,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);
		if ( $p ) {
			return $p[0];
		}
	}
	$p = br_posts( 'article', 1 );
	return $p ? $p[0] : null;
}

function br_count( $kind = 'all' ) {
	$all = (int) wp_count_posts( 'post' )->publish;
	if ( 'all' === $kind ) {
		return $all;
	}
	$t = count( br_thought_ids() );
	return 'thought' === $kind ? $t : max( 0, $all - $t );
}

function br_plural( $n, $one, $many ) {
	return $n . ' ' . ( 1 === (int) $n ? $one : $many );
}

/* ---------- Nav ---------- */

function br_active() {
	if ( is_front_page() ) {
		return 'home';
	}
	if ( is_search() || is_tag() || is_page_template( 'template-explore.php' ) || is_page( 'explore' ) ) {
		return 'explore';
	}
	if ( is_page_template( 'template-thoughts.php' ) || is_page( 'thoughts' ) || is_category( 'thoughts' ) || ( is_singular( 'post' ) && br_is_thought( get_queried_object() ) ) ) {
		return 'thoughts';
	}
	if ( is_page_template( 'template-blog.php' ) || is_page( 'blog' ) || is_singular( 'post' ) || is_home() || is_archive() ) {
		return 'blog';
	}
	if ( function_exists( 'br_is_tools_page' ) && ( br_is_tools_page() || br_is_builder_page() ) ) {
		return 'tools';
	}
	$about = br_page( 'about' );
	if ( $about && is_page( $about->ID ) ) {
		return 'about';
	}
	return '';
}

function br_nav_items() {
	return array(
		'home'     => array( home_url( '/' ), __( 'Home', 'beerandomly' ), __( 'Home', 'beerandomly' ) ),
		'explore'  => array( br_page_url( 'explore' ), __( 'Explore', 'beerandomly' ), __( 'Explore', 'beerandomly' ) ),
		'thoughts' => array( br_page_url( 'thoughts' ), __( 'Quick tips', 'beerandomly' ), __( 'Tips', 'beerandomly' ) ),
		'blog'     => array( br_page_url( 'blog' ), __( 'Guides', 'beerandomly' ), __( 'Guides', 'beerandomly' ) ),
		'tools'    => array( br_page_url( 'tools' ), __( 'Tools', 'beerandomly' ), __( 'Tools', 'beerandomly' ) ),
		'about'    => array( br_page_url( 'about' ), __( 'About', 'beerandomly' ), __( 'About', 'beerandomly' ) ),
	);
}

/* ---------- Top bar ---------- */

/**
 * Sticky bar at the top of the centre column.
 *
 * @param string $title Text.
 * @param string $mode  h1 | title (p) | back (p) | backh1.
 */
function br_topbar( $title, $mode = 'h1' ) {
	echo '<div class="topbar">';
	if ( 'back' === $mode || 'backh1' === $mode ) {
		echo '<a class="icon-btn" href="' . esc_url( home_url( '/' ) ) . '" data-back aria-label="' . esc_attr__( 'Back', 'beerandomly' ) . '">' . br_icon( 'back' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	} else {
		echo '<a class="mob-brand" href="' . esc_url( home_url( '/' ) ) . '" aria-label="' . esc_attr__( 'Home', 'beerandomly' ) . '"><svg viewBox="0 0 64 64" aria-hidden="true"><use href="#logo"/></svg></a>';
	}
	if ( 'title' === $mode || 'back' === $mode ) {
		echo '<p class="topbar-title">' . esc_html( $title ) . '</p>';
	} else {
		echo '<h1>' . esc_html( $title ) . '</h1>';
	}
	echo '<span class="grow"></span><button class="icon-btn mob-only" data-theme-toggle aria-label="' . esc_attr__( 'Switch theme', 'beerandomly' ) . '">' . br_icon( 'moon' ) . '</button></div>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
}

/** Is this one of the listing pages (Explore, Thoughts, Blog)? */
function br_is_listing_page() {
	if ( ! is_page() ) {
		return false;
	}
	foreach ( array( 'explore', 'thoughts', 'blog', 'tools', 'builder' ) as $k ) {
		if ( is_page_template( 'template-' . $k . '.php' ) ) {
			return true;
		}
		$p = br_page( $k );
		if ( $p && is_page( $p->ID ) ) {
			return true;
		}
	}
	return false;
}
