<?php
/**
 * Keep old static-site links working.
 *
 * @package beerandomly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'template_redirect',
	function () {
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore

		// Old /explore?tag=x links → the tag archive.
		if ( isset( $_GET['tag'] ) && preg_match( '#(^|/)explore$#', $path ) ) { // phpcs:ignore
			$t = get_term_by( 'slug', sanitize_title( wp_unslash( $_GET['tag'] ) ), 'post_tag' ); // phpcs:ignore
			if ( ! $t ) {
				$t = get_term_by( 'name', sanitize_text_field( wp_unslash( $_GET['tag'] ) ), 'post_tag' ); // phpcs:ignore
			}
			wp_safe_redirect( $t ? get_tag_link( $t ) : br_page_url( 'explore' ), 301 );
			exit;
		}

		if ( ! is_404() ) {
			return;
		}
		if ( 'rss.xml' === $path ) {
			wp_safe_redirect( get_feed_link(), 301 );
			exit;
		}
		if ( 'index.html' === $path ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
		// /about.html, /posts/slug.html, /posts/slug (old) → the WordPress page/post.
		$clean = preg_replace( '#\.html$#', '', $path );
		$slug  = basename( $clean );
		if ( $slug ) {
			$p = get_page_by_path( $slug, OBJECT, array( 'post', 'page' ) );
			if ( $p && 'publish' === $p->post_status ) {
				wp_safe_redirect( get_permalink( $p ), 301 );
				exit;
			}
		}
	},
	1
);
