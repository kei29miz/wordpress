<?php
/**
 * SEO: Open Graph, description, JSON-LD — only when no SEO plugin is active
 * (Rank Math, Yoast, AIOSEO, SEOPress and The SEO Framework handle it themselves).
 *
 * @package beerandomly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function br_has_seo_plugin() {
	return defined( 'WPSEO_VERSION' ) || class_exists( 'RankMath' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'THE_SEO_FRAMEWORK_VERSION' );
}

/* Home page title like the original: "Bee Randomly — Random Thoughts About Life". */
add_filter(
	'document_title_separator',
	function ( $sep ) {
		return br_has_seo_plugin() ? $sep : '—';
	}
);

add_action(
	'wp_head',
	function () {
		if ( br_has_seo_plugin() ) {
			return;
		}
		$site  = br_name();
		$title = wp_get_document_title();
		$img   = get_theme_file_uri( 'assets/og/og-default.png' );
		$type  = 'website';
		$desc  = '';
		$url   = '';

		if ( is_front_page() ) {
			$url  = home_url( '/' );
			$desc = br_tagline();
		} elseif ( is_singular() ) {
			$p    = get_queried_object();
			$url  = get_permalink( $p );
			$desc = br_excerpt( $p );
			$img  = br_og_image( $p );
			$type = is_singular( 'post' ) ? 'article' : 'website';
		} elseif ( is_tag() ) {
			$url  = get_tag_link( get_queried_object() );
			$desc = wp_strip_all_tags( (string) term_description() );
		}
		if ( ! $url ) {
			return;
		}
		$desc = br_short( $desc, 200 );

		if ( $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		echo '<meta property="og:site_name" content="' . esc_attr( $site ) . '">' . "\n";
		echo '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
		if ( $desc ) {
			echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
		echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
		if ( $desc ) {
			echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		echo '<meta name="twitter:image" content="' . esc_url( $img ) . '">' . "\n";

		$person = array(
			'@type' => 'Person',
			'@id'   => br_page_url( 'about' ) . '#person',
			'name'  => $site,
			'url'   => br_page_url( 'about' ),
		);
		if ( is_front_page() ) {
			$graph = array(
				'@context'    => 'https://schema.org',
				'@type'       => 'WebSite',
				'@id'         => home_url( '/#website' ),
				'url'         => home_url( '/' ),
				'name'        => $site,
				'description' => $desc,
				'author'      => $person,
				'inLanguage'  => get_bloginfo( 'language' ),
			);
		} elseif ( is_singular( 'post' ) ) {
			$p     = get_queried_object();
			$names = wp_list_pluck( br_tags( $p ), 'name' );
			$graph = array(
				'@context' => 'https://schema.org',
				'@graph'   => array(
					array(
						'@type'            => 'BlogPosting',
						'mainEntityOfPage' => array(
							'@type' => 'WebPage',
							'@id'   => $url,
						),
						'headline'         => br_title( $p ),
						'description'      => $desc,
						'datePublished'    => get_post_time( 'c', true, $p ),
						'dateModified'     => get_post_modified_time( 'c', true, $p ),
						'author'           => $person,
						'publisher'        => $person,
						'image'            => $img,
						'keywords'         => implode( ', ', $names ),
						'wordCount'        => br_words( $p ),
						'inLanguage'       => get_bloginfo( 'language' ),
					),
					array(
						'@type'           => 'BreadcrumbList',
						'itemListElement' => array(
							array(
								'@type'    => 'ListItem',
								'position' => 1,
								'name'     => __( 'Home', 'beerandomly' ),
								'item'     => home_url( '/' ),
							),
							array(
								'@type'    => 'ListItem',
								'position' => 2,
								'name'     => br_is_thought( $p ) ? __( 'Thoughts', 'beerandomly' ) : __( 'Blog posts', 'beerandomly' ),
								'item'     => br_is_thought( $p ) ? br_page_url( 'thoughts' ) : br_page_url( 'blog' ),
							),
							array(
								'@type'    => 'ListItem',
								'position' => 3,
								'name'     => br_title( $p ),
								'item'     => $url,
							),
						),
					),
				),
			);
		} else {
			return;
		}
		echo '<script type="application/ld+json">' . wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
	},
	5
);

/* robots.txt: same rules as the original site (search + AI answers yes, AI training no). */
add_filter(
	'robots_txt',
	function ( $output, $public ) {
		if ( ! $public || ! get_theme_mod( 'br_robots_ai', 1 ) || false !== strpos( $output, 'Content-Signal' ) ) {
			return $output;
		}
		$bots = array( 'GPTBot', 'ClaudeBot', 'Google-Extended', 'Applebot-Extended', 'CCBot', 'Bytespider', 'cohere-ai', 'Amazonbot', 'meta-externalagent', 'GoogleOther', 'Google-CloudVertexBot' );
		$add  = "\n# Content signals: https://contentsignals.org\nUser-agent: *\nContent-Signal: search=yes, ai-input=yes, ai-train=no, use=reference\n\n# Training-only crawlers. These do not affect search or AI answers.\n";
		foreach ( $bots as $b ) {
			$add .= 'User-agent: ' . $b . "\n";
		}
		$add .= "Disallow: /\n";
		return rtrim( $output ) . "\n" . $add;
	},
	99,
	2
);
