<?php
/**
 * Theme setup, assets, Customizer, activation tasks.
 *
 * @package beerandomly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action(
	'after_setup_theme',
	function () {
		load_theme_textdomain( 'beerandomly', get_template_directory() . '/languages' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
		add_theme_support( 'post-formats', array( 'quote', 'aside' ) );
		add_theme_support( 'editor-styles' );
		add_editor_style( array( 'https://fonts.googleapis.com/css2?family=Caveat:wght@600;700&family=Literata:ital,opsz,wght@0,7..72,400..600;1,7..72,400..500&display=swap', 'assets/css/editor.css' ) );
		add_post_type_support( 'page', 'excerpt' );
	}
);

/* No comments anywhere (the design has none). */
add_filter( 'comments_open', '__return_false', 20 );
add_filter( 'pings_open', '__return_false', 20 );

add_filter(
	'excerpt_length',
	function () {
		return 30;
	}
);
add_filter(
	'excerpt_more',
	function () {
		return '…';
	}
);

/* ---------- Assets ---------- */

add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'br-fonts', 'https://fonts.googleapis.com/css2?family=Caveat:wght@600;700&family=Literata:ital,opsz,wght@0,7..72,400..600;1,7..72,400..500&display=swap', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
		wp_enqueue_style( 'br-style', get_stylesheet_uri(), array( 'br-fonts' ), BR_VERSION );
		wp_enqueue_style( 'br-wp', get_theme_file_uri( 'assets/css/wp.css' ), array( 'br-style' ), BR_VERSION );
		wp_enqueue_script( 'br-site', get_theme_file_uri( 'assets/js/site.js' ), array(), BR_VERSION, true );

		$pool = array();
		foreach ( br_posts( 'all', 300 ) as $p ) {
			$pool[] = get_permalink( $p );
		}
		wp_add_inline_script(
			'br-site',
			'window.BR=' . wp_json_encode(
				array(
					'posts'   => $pool,
					'home'    => home_url( '/' ),
					'explore' => br_page_url( 'explore' ),
					'i18n'    => array(
						'copied'  => __( 'Link copied', 'beerandomly' ),
						'copiedB' => __( 'Copied ✓', 'beerandomly' ),
						'copy'    => __( 'Copy link', 'beerandomly' ),
						'prompt'  => __( 'Copy this link', 'beerandomly' ),
						'nothing' => __( 'Nothing to land on yet', 'beerandomly' ),
					),
				)
			) . ';',
			'before'
		);
	}
);

/* WordPress's global-styles block is for block themes; in this classic theme it only fights style.css. Block styles stay (posts may use blocks). */
add_action(
	'wp_enqueue_scripts',
	function () {
		wp_dequeue_style( 'global-styles' );
		wp_dequeue_style( 'classic-theme-styles' );
	},
	100
);
remove_action( 'wp_body_open', 'wp_global_styles_render_svg_filters' );

add_action(
	'wp_head',
	function () {
		echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
		// Apply the saved light/dark choice before paint (no flash).
		echo '<script>try{var t=localStorage.getItem("br-theme");if(t)document.documentElement.dataset.theme=t}catch(e){}</script>' . "\n";
	},
	1
);

/* Favicons (only when no Site Icon is set in Customizer). */
add_action(
	'wp_head',
	function () {
		if ( has_site_icon() ) {
			return;
		}
		$u = get_theme_file_uri( 'assets/og/' );
		foreach ( array( 192, 96, 48, 32 ) as $s ) {
			echo '<link rel="icon" href="' . esc_url( $u . 'favicon-' . $s . '.png' ) . '" sizes="' . (int) $s . 'x' . (int) $s . '">' . "\n";
		}
		echo '<link rel="apple-touch-icon" href="' . esc_url( $u . 'apple-touch-icon.png' ) . '">' . "\n";
	},
	2
);

/* ---------- Body classes ---------- */

add_filter(
	'body_class',
	function ( $c ) {
		// Single posts and plain pages (About, Privacy…) use the wide reading layout, like the original site.
		if ( is_singular( 'post' ) || ( is_page() && ! is_front_page() && ! br_is_listing_page() ) ) {
			$c[] = 'reading';
		}
		return array_unique( $c );
	}
);

/* ---------- Customizer ---------- */

add_action(
	'customize_register',
	function ( $wp_customize ) {
		$wp_customize->add_section(
			'br_profile',
			array(
				'title'       => __( 'Bee Randomly', 'beerandomly' ),
				'description' => __( 'Site name and tagline are under Site Identity.', 'beerandomly' ),
				'priority'    => 30,
			)
		);
		$wp_customize->add_setting(
			'br_bio',
			array(
				'default'           => BR_DEFAULT_BIO,
				'sanitize_callback' => 'sanitize_textarea_field',
			)
		);
		$wp_customize->add_control(
			'br_bio',
			array(
				'section' => 'br_profile',
				'label'   => __( 'Short bio (home card and “Written by” box)', 'beerandomly' ),
				'type'    => 'textarea',
			)
		);
		$wp_customize->add_setting(
			'br_location',
			array(
				'default'           => 'Quezon City',
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
		$wp_customize->add_control(
			'br_location',
			array(
				'section' => 'br_profile',
				'label'   => __( 'Location (About page byline)', 'beerandomly' ),
				'type'    => 'text',
			)
		);
		$wp_customize->add_setting(
			'br_robots_ai',
			array(
				'default'           => 1,
				'sanitize_callback' => 'absint',
			)
		);
		$wp_customize->add_control(
			'br_robots_ai',
			array(
				'section' => 'br_profile',
				'label'   => __( 'robots.txt: allow search and AI answers, block AI training crawlers', 'beerandomly' ),
				'type'    => 'checkbox',
			)
		);
	}
);

/* ---------- Activation: make sure everything the design needs exists ---------- */

function br_install() {
	// Thoughts category.
	if ( ! term_exists( 'thoughts', 'category' ) ) {
		wp_insert_term( 'Quick tips', 'category', array( 'slug' => 'thoughts' ) );
	}
	$tid = br_thoughts_term_id();
	// The old "Thoughts" category is renamed "Quick tips" (slug unchanged).
	$cat = get_category_by_slug( 'thoughts' );
	if ( $cat && 'Thoughts' === $cat->name ) {
		wp_update_term( $cat->term_id, 'category', array( 'name' => 'Quick tips' ) );
	}

	// Posts marked as thoughts in the original site go into the Thoughts category.
	foreach ( br_cover_map() as $slug => $m ) {
		if ( empty( $m['type'] ) || 'thought' !== $m['type'] || ! $tid ) {
			continue;
		}
		$p = get_page_by_path( $slug, OBJECT, 'post' );
		if ( $p && ! has_category( 'thoughts', $p ) ) {
			wp_set_post_categories( $p->ID, array( $tid ), true );
		}
	}

	// Explore / Thoughts / Blog / About / Privacy pages.
	$pages = array(
		'explore'  => array( 'Explore', 'template-explore.php' ),
		'thoughts' => array( 'Quick tips', 'template-thoughts.php' ),
		'blog'     => array( 'Guides', 'template-blog.php' ),
		'tools'    => array( 'Tools', 'template-tools.php' ),
		'website-builder' => array( 'Website builder', 'template-builder.php' ),
		'about'    => array( 'About', '' ),
		'privacy'  => array( 'Privacy', '' ),
	);
	foreach ( $pages as $slug => $d ) {
		$p = get_page_by_path( $slug );
		if ( ! $p ) {
			$id = wp_insert_post(
				array(
					'post_title'   => $d[0],
					'post_name'    => $slug,
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'post_content' => '',
				)
			);
		} else {
			$id = $p->ID;
			// Rename the old default titles (URLs stay the same).
			$old = array( 'thoughts' => 'Thoughts', 'blog' => 'Blog posts' );
			if ( isset( $old[ $slug ] ) && $old[ $slug ] === $p->post_title ) {
				wp_update_post( array( 'ID' => $id, 'post_title' => $d[0] ) );
			}
		}
		if ( $d[1] && $id && ! is_wp_error( $id ) ) {
			$cur = get_post_meta( $id, '_wp_page_template', true );
			if ( ! $cur || 'default' === $cur ) {
				update_post_meta( $id, '_wp_page_template', $d[1] );
			}
		}
	}

	// Friendly permalinks that match the old static URLs (/posts/slug/), only if still on "Plain".
	if ( ! get_option( 'permalink_structure' ) ) {
		global $wp_rewrite;
		$wp_rewrite->set_permalink_structure( '/posts/%postname%/' );
	}
	flush_rewrite_rules( false );
	update_option( 'br_installed', BR_VERSION, false );
}
add_action( 'after_switch_theme', 'br_install' );

/* Also run once after a theme update (uploading a new version doesn't fire after_switch_theme). */
add_action(
	'admin_init',
	function () {
		if ( get_option( 'br_installed' ) !== BR_VERSION ) {
			br_install();
		}
	}
);
