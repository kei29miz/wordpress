<?php
/**
 * Tools tab: free Website Builder, its download email gate, and the email list in wp-admin.
 *
 * @package beerandomly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Starter templates bundled in assets/templates/. */
function br_builder_templates() {
	return array(
		array(
			'id'    => 'reese-calloway',
			'name'  => 'Portfolio — Reese Calloway',
			'desc'  => 'A multi-page portfolio for freelancers, VAs and social media managers: about, skills, case studies and contact.',
			'cv'    => 'cv-dusk',
			'files' => array( 'index.html', 'style.css', 'script.js' ),
		),
		array(
			'id'    => 'blank',
			'name'  => 'Simple one-page site',
			'desc'  => 'A clean starting point with a headline, about, services and contact section.',
			'cv'    => 'cv-meadow',
			'files' => array( 'index.html', 'style.css' ),
		),
	);
}

function br_is_builder_page() {
	if ( ! is_page() ) {
		return false;
	}
	if ( is_page_template( 'template-builder.php' ) ) {
		return true;
	}
	$p = br_page( 'builder' );
	return $p && is_page( $p->ID );
}

function br_is_tools_page() {
	if ( ! is_page() ) {
		return false;
	}
	if ( is_page_template( 'template-tools.php' ) ) {
		return true;
	}
	$p = br_page( 'tools' );
	return $p && is_page( $p->ID );
}

/* Wide layout (no right rail) for the builder. */
add_filter(
	'body_class',
	function ( $c ) {
		if ( br_is_builder_page() ) {
			$c[] = 'writing';
			$c[] = 'builder';
		}
		return $c;
	},
	20
);

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! br_is_builder_page() && ! br_is_tools_page() ) {
			return;
		}
		wp_enqueue_style( 'br-builder', get_theme_file_uri( 'assets/css/builder.css' ), array( 'br-style' ), BR_VERSION );
		if ( ! br_is_builder_page() ) {
			return;
		}
		wp_enqueue_script( 'br-jszip', get_theme_file_uri( 'assets/js/jszip.min.js' ), array(), '3.10.1', true );
		wp_enqueue_script( 'br-builder', get_theme_file_uri( 'assets/js/builder.js' ), array( 'br-jszip' ), BR_VERSION, true );
		$tpls = array();
		foreach ( br_builder_templates() as $t ) {
			$t['base'] = get_theme_file_uri( 'assets/templates/' . $t['id'] . '/' );
			$tpls[]    = $t;
		}
		wp_add_inline_script(
			'br-builder',
			'window.BRB=' . wp_json_encode(
				array(
					'templates' => $tpls,
					'lead'      => rest_url( 'beerandomly/v1/builder-lead' ),
					'privacy'   => br_page_url( 'privacy' ),
					'site'      => br_name(),
				)
			) . ';',
			'before'
		);
	}
);

/* ---------- Emails collected before download ---------- */

add_action(
	'init',
	function () {
		register_post_type(
			'br_lead',
			array(
				'labels'          => array(
					'name'          => __( 'Builder emails', 'beerandomly' ),
					'singular_name' => __( 'Builder email', 'beerandomly' ),
					'search_items'  => __( 'Search emails', 'beerandomly' ),
					'not_found'     => __( 'No emails yet.', 'beerandomly' ),
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => true,
				'menu_position'   => 26,
				'menu_icon'       => 'dashicons-email-alt',
				'supports'        => array( 'title' ),
				'capability_type' => 'post',
				'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
				'map_meta_cap'    => true,
				'show_in_rest'    => false,
			)
		);
	}
);

add_action(
	'rest_api_init',
	function () {
		register_rest_route(
			'beerandomly/v1',
			'/builder-lead',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => 'br_builder_lead',
			)
		);
	}
);

function br_builder_lead( WP_REST_Request $req ) {
	// Honeypot: real people never fill this field.
	if ( '' !== trim( (string) $req->get_param( 'website' ) ) ) {
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}
	$email = sanitize_email( (string) $req->get_param( 'email' ) );
	if ( ! $email || ! is_email( $email ) ) {
		return new WP_Error( 'br_email', __( 'Enter a valid email address.', 'beerandomly' ), array( 'status' => 400 ) );
	}
	// Simple rate limit: 20 submissions per hour per visitor.
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'br_lead_' . md5( $ip . wp_salt() );
	$n   = (int) get_transient( $key );
	if ( $n >= 20 ) {
		return new WP_Error( 'br_rate', __( 'Too many tries. Wait an hour and try again.', 'beerandomly' ), array( 'status' => 429 ) );
	}
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );

	$template = sanitize_text_field( (string) $req->get_param( 'template' ) );
	$existing = get_posts(
		array(
			'post_type'      => 'br_lead',
			'post_status'    => 'private',
			'title'          => $email,
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);
	if ( $existing ) {
		$id = (int) $existing[0];
		update_post_meta( $id, '_br_downloads', (int) get_post_meta( $id, '_br_downloads', true ) + 1 );
		update_post_meta( $id, '_br_last', current_time( 'mysql' ) );
	} else {
		$id = wp_insert_post(
			array(
				'post_type'   => 'br_lead',
				'post_status' => 'private',
				'post_title'  => $email,
			)
		);
		if ( ! $id || is_wp_error( $id ) ) {
			return new WP_Error( 'br_save', __( 'Your email could not be saved. Try again.', 'beerandomly' ), array( 'status' => 500 ) );
		}
		update_post_meta( $id, '_br_downloads', 1 );
		update_post_meta( $id, '_br_last', current_time( 'mysql' ) );
	}
	if ( $template ) {
		update_post_meta( $id, '_br_template', $template );
	}
	return new WP_REST_Response( array( 'ok' => true ), 200 );
}

/* Admin list columns. */
add_filter(
	'manage_br_lead_posts_columns',
	function () {
		return array(
			'cb'        => '<input type="checkbox">',
			'title'     => __( 'Email', 'beerandomly' ),
			'template'  => __( 'Started from', 'beerandomly' ),
			'downloads' => __( 'Downloads', 'beerandomly' ),
			'last'      => __( 'Last download', 'beerandomly' ),
			'date'      => __( 'First download', 'beerandomly' ),
		);
	}
);
add_action(
	'manage_br_lead_posts_custom_column',
	function ( $col, $id ) {
		if ( 'template' === $col ) {
			echo esc_html( (string) get_post_meta( $id, '_br_template', true ) );
		} elseif ( 'downloads' === $col ) {
			echo (int) get_post_meta( $id, '_br_downloads', true );
		} elseif ( 'last' === $col ) {
			echo esc_html( (string) get_post_meta( $id, '_br_last', true ) );
		}
	},
	10,
	2
);

/* "Download CSV" button above the list. */
add_action(
	'manage_posts_extra_tablenav',
	function ( $which ) {
		$screen = get_current_screen();
		if ( 'top' !== $which || ! $screen || 'br_lead' !== $screen->post_type || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=br_leads_csv' ), 'br_leads_csv' );
		echo '<div class="alignleft actions"><a class="button" href="' . esc_url( $url ) . '">' . esc_html__( 'Download CSV', 'beerandomly' ) . '</a></div>';
	}
);

add_action(
	'admin_post_br_leads_csv',
	function () {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'beerandomly' ) );
		}
		check_admin_referer( 'br_leads_csv' );
		$ids = get_posts(
			array(
				'post_type'      => 'br_lead',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=builder-emails-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fputcsv( $out, array( 'email', 'started_from', 'downloads', 'first_download', 'last_download' ) );
		foreach ( $ids as $id ) {
			fputcsv(
				$out,
				array(
					get_the_title( $id ),
					get_post_meta( $id, '_br_template', true ),
					(int) get_post_meta( $id, '_br_downloads', true ),
					get_post_field( 'post_date', $id ),
					get_post_meta( $id, '_br_last', true ),
				)
			);
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}
);
