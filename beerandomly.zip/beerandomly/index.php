<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
br_topbar( is_home() ? __( 'Guides', 'beerandomly' ) : wp_strip_all_tags( get_the_archive_title() ) );
echo '<div class="stack"><section class="card feed">';
if ( have_posts() ) { while ( have_posts() ) { the_post(); br_acard( get_post() ); } } else { echo '<div class="empty"><h2>' . esc_html__( 'Nothing here yet', 'beerandomly' ) . '</h2></div>'; }
echo '</section>';
the_posts_pagination( array( 'prev_text' => '←', 'next_text' => '→' ) );
echo '</div>';
get_footer();
