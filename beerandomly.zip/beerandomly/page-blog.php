<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require __DIR__ . '/template-blog.php';
