<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require __DIR__ . '/template-thoughts.php';
