<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
require __DIR__ . '/template-tools.php';
