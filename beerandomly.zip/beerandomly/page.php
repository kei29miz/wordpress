<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) :
	the_post();
	$about = br_page( 'about' );
	$is_about = $about && (int) $about->ID === get_the_ID();
	$title = get_the_title();
	br_topbar( $is_about ? __( 'About', 'beerandomly' ) : $title, 'title' );
	?>
<div class="stack"><article class="card" id="detail"><?php
	if ( has_post_thumbnail() ) {
		echo '<div class="art-cover-img">' . get_the_post_thumbnail( null, 'large', array( 'fetchpriority' => 'high' ) ) . '</div>';
	} elseif ( $is_about ) {
		echo '<div class="cv cv-honey"><div class="art-cover"></div></div>';
	}
	?><div class="art-in"><div class="kicker" style="margin-top:0"><span class="dot"></span><?php echo esc_html( $is_about ? __( 'About', 'beerandomly' ) : $title ); ?></div><h1 class="art-title"><?php echo esc_html( $title ); ?></h1><?php
	if ( has_excerpt() ) { echo '<p class="art-sub">' . esc_html( get_the_excerpt() ) . '</p>'; }
	if ( $is_about ) {
		echo '<div class="art-byline">' . br_avatar() . '<div class="who"><b>' . esc_html( br_name() ) . '</b><span>' . esc_html( br_location() ) . '</span></div><div class="byl-acts">' . br_share_btn( get_permalink(), $title ) . '</div></div>'; // phpcs:ignore
	}
	echo '<div class="prose dc-classic f-serif sz-m ac-honey">';
	the_content();
	wp_link_pages();
	echo '</div>';
	if ( $is_about ) { br_share_box( __( 'Share this page', 'beerandomly' ) ); }
	?></div></article><?php
	if ( $is_about ) { br_more_from( sprintf( __( 'Latest from %s', 'beerandomly' ), br_name() ) ); }
	echo '</div>';
endwhile;
get_footer();
