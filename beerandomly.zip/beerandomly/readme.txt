=== Bee Randomly ===
Requires at least: 6.0 | Tested up to: 7.0 | Requires PHP: 7.4 | License: GPLv2 or later

A help site for AI users and anyone who wants to earn with AI.

Install: Appearance → Themes → Add New → Upload Theme → beerandomly.zip → "Replace current with uploaded" → Activate.

- Guides = full articles (how-tos, tool reviews, earning walkthroughs).
- Quick tips = one-liners: set Type to "Quick tip" in the "Bee Randomly display" box (or use the Quick tips category).
- Featured guide on Home = a post marked "Stick to the top of the blog" (else the newest guide).
- Cover image = Featured image. Use tags as topics (e.g. #prompts, #freelancing, #ChatGPT, #side-hustles).
- Bio / location: Appearance → Customize → Bee Randomly. Tagline: Settings → General (empty = "Learn AI, use it well, and earn from it").
- Pages Explore, Quick tips and Guides use the templates of the same name (created automatically). Their URLs (/explore/, /thoughts/, /blog/) are unchanged so old links keep working.
