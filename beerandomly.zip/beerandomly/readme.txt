=== Bee Randomly ===
Requires at least: 6.0 | Tested up to: 7.0 | Requires PHP: 7.4 | License: GPLv2 or later

Install: Appearance → Themes → Add New → Upload Theme → beerandomly.zip → "Replace current with uploaded" → Activate.

- Featured story on Home = a post marked "Stick to the top of the blog" (else the newest article).
- Thoughts = posts with Type "Thought" in the "Bee Randomly display" box (or the Thoughts category).
- Cover image = Featured image. The original posts use bundled covers automatically.
- Bio / location: Appearance → Customize → Bee Randomly. Tagline: Settings → General.
- Pages Explore, Thoughts, Blog posts use the templates of the same name (created automatically).
