<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
br_topbar( __( 'Search', 'beerandomly' ) );
?><div class="stack"><section class="card"><div class="big-search"><form class="search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo br_icon( 'explore' ); // phpcs:ignore ?><input type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" aria-label="Search"></form></div></section>
<section class="card feed"><div class="ex-head"><h2>“<?php echo esc_html( get_search_query() ); ?>”</h2></div><?php
if ( have_posts() ) { while ( have_posts() ) { the_post(); if ( 'post' === get_post_type() ) { br_acard( get_post() ); } } } else { echo '<div class="empty"><h2>' . esc_html__( 'No matches', 'beerandomly' ) . '</h2><p>' . esc_html__( 'Try a different word or topic.', 'beerandomly' ) . '</p></div>'; }
?></section></div>
<?php get_footer();
