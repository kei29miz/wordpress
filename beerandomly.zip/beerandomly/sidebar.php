<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?><aside class="right" aria-label="Explore"><?php br_search_form(); ?>
<?php
$tags = get_tags( array( 'orderby' => 'count', 'order' => 'DESC', 'number' => 6, 'hide_empty' => true ) );
if ( $tags && ! is_wp_error( $tags ) ) {
	echo '<section class="card panel" style="margin-top:14px"><h2>' . esc_html__( 'Trending topics', 'beerandomly' ) . '</h2>';
	foreach ( $tags as $t ) {
		echo '<a class="trend" href="' . esc_url( get_tag_link( $t ) ) . '"><b>#' . esc_html( $t->name ) . '</b><small>' . esc_html( br_plural( $t->count, 'post', 'posts' ) ) . '</small></a>';
	}
	echo '</section>';
}
$latest = br_posts( 'all', 4 );
if ( $latest ) {
	echo '<section class="card panel" style="margin-top:14px"><h2>' . esc_html__( 'Latest', 'beerandomly' ) . '</h2>';
	foreach ( $latest as $p ) {
		echo '<a class="trend" href="' . esc_url( get_permalink( $p ) ) . '"><b>' . esc_html( br_title( $p ) ) . '</b><small><time datetime="' . esc_attr( get_the_date( 'Y-m-d', $p ) ) . '">' . esc_html( get_the_date( 'M j, Y', $p ) ) . '</time></small></a>';
	}
	echo '</section>';
}
?><p class="foot-note"><?php echo esc_html( br_name() ); ?> · <a href="<?php echo esc_url( br_page_url( 'privacy' ) ); ?>"><?php esc_html_e( 'Privacy', 'beerandomly' ); ?></a></p></aside>
