<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) :
	the_post();
	$post_obj = get_post();
	$thought  = br_is_thought( $post_obj );
	$title    = br_title( $post_obj );
	$url      = get_permalink();
	$tags     = br_tags( $post_obj );
	br_topbar( $title, $thought ? 'backh1' : 'back' );
	$kick = ( $thought ? __( 'Thought', 'beerandomly' ) : __( 'Article', 'beerandomly' ) ) . ( $tags ? ' in #' . $tags[0]->name : '' );
	$byline = '<div class="art-byline">' . br_avatar() . '<div class="who"><b>' . esc_html( br_name() ) . '</b><span><time datetime="' . esc_attr( get_the_date( 'Y-m-d' ) ) . '">' . esc_html( get_the_date( 'F j, Y' ) ) . '</time> · ' . esc_html( br_read_label( $post_obj ) ) . '</span></div><div class="byl-acts">' . br_share_btn( $url, br_short( $title, 50 ) ) . '</div></div>';
	?>
<div class="stack"><article class="card" id="detail"><?php
	if ( ! $thought ) {
		$c = br_cover( $post_obj );
		if ( $c ) {
			echo '<div class="art-cover-img">' . br_cover_img( $c, array( 'fetchpriority' => 'high' ) ) . '</div>'; // phpcs:ignore
			if ( $c['credit'] ) {
				echo '<p class="cover-credit">' . ( $c['credit_url'] ? '<a href="' . esc_url( $c['credit_url'] ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $c['credit'] ) . '</a>' : esc_html( $c['credit'] ) ) . '</p>';
			}
		} else {
			echo '<div class="cv ' . esc_attr( br_cv_class( $post_obj ) ) . '"><div class="art-cover"></div></div>';
		}
	}
	?><div class="art-in"><div class="kicker <?php echo $thought ? 't' : ''; ?>" style="margin-top:0"><span class="dot"></span><?php echo esc_html( $kick ); ?></div><?php
	if ( $thought ) {
		echo '<div class="tq-panel ' . esc_attr( br_tc_class( $post_obj ) ) . '"><div class="art-quote ' . esc_attr( br_opt( $post_obj, 'tf' ) ? br_opt( $post_obj, 'tf' ) : 'tf-serif' ) . '">';
		if ( '' !== trim( $post_obj->post_content ) ) { the_content(); } else { echo '<p>' . esc_html( $title ) . '</p>'; }
		echo '</div></div>' . $byline; // phpcs:ignore
	} else {
		echo '<h1 class="art-title">' . esc_html( $title ) . '</h1>';
		if ( has_excerpt() ) { echo '<p class="art-sub">' . esc_html( get_the_excerpt() ) . '</p>'; }
		echo $byline; // phpcs:ignore
		$prose = br_opt( $post_obj, 'prose' ) ? br_opt( $post_obj, 'prose' ) : 'dc-classic f-serif sz-m ac-honey';
		echo '<div class="prose ' . esc_attr( $prose ) . '">';
		the_content();
		wp_link_pages();
		echo '</div>';
	}
	if ( $tags ) { echo '<div class="tags">'; foreach ( $tags as $t ) { echo br_tag_link( $t ); } echo '</div>'; } // phpcs:ignore
	br_share_box( $thought ? __( 'Share this thought', 'beerandomly' ) : __( 'Share this post', 'beerandomly' ) );
	br_author_box();
	?></div></article>
<?php
	$older = get_previous_post();
	$newer = get_next_post();
	if ( $older || $newer ) {
		echo '<nav class="pn" aria-label="More posts">';
		if ( $older ) { echo '<a href="' . esc_url( get_permalink( $older ) ) . '"><small>' . esc_html__( 'Older', 'beerandomly' ) . '</small><b>' . esc_html( br_short( br_title( $older ), 50 ) ) . '</b></a>'; }
		if ( $newer ) { echo '<a href="' . esc_url( get_permalink( $newer ) ) . '"><small>' . esc_html__( 'Newer', 'beerandomly' ) . '</small><b>' . esc_html( br_short( br_title( $newer ), 50 ) ) . '</b></a>'; }
		echo '</nav>';
	}
	br_more_from( sprintf( __( 'More from %s', 'beerandomly' ), br_name() ), array( get_the_ID() ) );
	echo '</div>';
endwhile;
get_footer();
