<?php
/**
 * Template Name: Blog posts
 *
 * @package beerandomly
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
br_topbar( get_the_title() ? get_the_title() : __( 'Guides', 'beerandomly' ) );
$posts = br_posts( 'article' );
$mins  = 0;
foreach ( $posts as $p ) { $mins += br_minutes( $p ); }
echo '<div class="stack">';
br_page_head( get_the_title() ? get_the_title() : __( 'Guides', 'beerandomly' ), br_plural( count( $posts ), 'guide', 'guides' ) . ' · ~' . $mins . ' min of reading', 'blog', 'cv-honey' );
?><h2 class="sr-only"><?php esc_html_e( 'All guides', 'beerandomly' ); ?></h2><div class="psort"><button type="button" data-bsort="new" aria-pressed="true"><?php esc_html_e( 'Newest', 'beerandomly' ); ?></button><button type="button" data-bsort="quick" aria-pressed="false"><?php esc_html_e( 'Quick reads', 'beerandomly' ); ?></button></div><section class="card feed" id="blogList"><?php
foreach ( $posts as $p ) { br_acard( $p ); }
?></section></div>
<?php get_footer();
