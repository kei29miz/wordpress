<?php
/**
 * Template Name: Website Builder
 *
 * @package beerandomly
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
br_topbar( get_the_title() ? get_the_title() : __( 'Website builder', 'beerandomly' ) );
?>
<div class="bld" id="bld">

<section class="card bld-start" id="bldStart">
	<div class="bld-start-head">
		<p class="ph-title"><?php esc_html_e( 'Build your website for free', 'beerandomly' ); ?></p>
		<p><?php esc_html_e( 'Choose a starting point. Click any text, image, button or section to change it, then download your site as a .zip ready for Vercel or Cloudflare Pages.', 'beerandomly' ); ?></p>
	</div>
	<div class="bld-resume" id="bldResume" hidden>
		<div><b><?php esc_html_e( 'Continue where you left off', 'beerandomly' ); ?></b><span id="bldResumeInfo"></span></div>
		<button class="btn btn-primary" type="button" id="bldResumeBtn"><?php esc_html_e( 'Continue editing', 'beerandomly' ); ?></button>
	</div>
	<div class="bld-tpls" id="bldTpls"></div>
	<label class="bld-upload">
		<input type="file" id="bldUpload" accept=".zip,.html,.htm,application/zip,text/html">
		<b><?php esc_html_e( 'Upload your own site', 'beerandomly' ); ?></b>
		<span><?php esc_html_e( 'A .zip with an index.html (plus its CSS, scripts and images), or a single .html file.', 'beerandomly' ); ?></span>
	</label>
	<p class="bld-note"><?php esc_html_e( 'Your work is saved in this browser only. Nothing is uploaded until you download.', 'beerandomly' ); ?></p>
	<p class="form-error" id="bldStartErr" role="alert" hidden></p>
</section>

<div class="bld-app" id="bldApp" hidden>
	<div class="card bld-bar" role="toolbar" aria-label="<?php esc_attr_e( 'Builder', 'beerandomly' ); ?>">
		<label class="bld-pages" id="bldPagesWrap" hidden><span class="sr-only"><?php esc_html_e( 'Page', 'beerandomly' ); ?></span><select id="bldPages"></select></label>
		<div class="bld-grp">
			<button type="button" class="tb" id="bldUndo" title="<?php esc_attr_e( 'Undo (Ctrl+Z)', 'beerandomly' ); ?>" aria-label="<?php esc_attr_e( 'Undo', 'beerandomly' ); ?>"><svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/></svg></button>
			<button type="button" class="tb" id="bldRedo" title="<?php esc_attr_e( 'Redo (Ctrl+Y)', 'beerandomly' ); ?>" aria-label="<?php esc_attr_e( 'Redo', 'beerandomly' ); ?>"><svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="m15 14 5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13"/></svg></button>
		</div>
		<div class="seg2" role="group" aria-label="<?php esc_attr_e( 'Screen size', 'beerandomly' ); ?>">
			<button type="button" data-dev="desk" aria-pressed="true"><?php esc_html_e( 'Desktop', 'beerandomly' ); ?></button>
			<button type="button" data-dev="tab" aria-pressed="false"><?php esc_html_e( 'Tablet', 'beerandomly' ); ?></button>
			<button type="button" data-dev="mob" aria-pressed="false"><?php esc_html_e( 'Phone', 'beerandomly' ); ?></button>
		</div>
		<div class="seg2" role="group" aria-label="<?php esc_attr_e( 'Mode', 'beerandomly' ); ?>">
			<button type="button" data-mode="edit" aria-pressed="true"><?php esc_html_e( 'Edit', 'beerandomly' ); ?></button>
			<button type="button" data-mode="preview" aria-pressed="false"><?php esc_html_e( 'Preview', 'beerandomly' ); ?></button>
		</div>
		<span class="grow"></span>
		<span class="w-status" id="bldStatus" aria-live="polite"></span>
		<button type="button" class="btn btn-quiet" id="bldFull"><?php esc_html_e( 'Full screen', 'beerandomly' ); ?></button>
		<button type="button" class="btn btn-outline" id="bldNew"><?php esc_html_e( 'Start over', 'beerandomly' ); ?></button>
		<button type="button" class="btn btn-primary" id="bldDownload"><?php esc_html_e( 'Download .zip', 'beerandomly' ); ?></button>
	</div>
	<div class="bld-main">
		<div class="bld-canvas" id="bldCanvas">
			<iframe id="bldFrame" title="<?php esc_attr_e( 'Your website (editing)', 'beerandomly' ); ?>" sandbox="allow-same-origin"></iframe>
			<iframe id="bldPreview" title="<?php esc_attr_e( 'Your website (preview)', 'beerandomly' ); ?>" sandbox="allow-scripts allow-forms allow-popups allow-modals" hidden></iframe>
		</div>
		<aside class="card bld-panel" aria-label="<?php esc_attr_e( 'Edit panel', 'beerandomly' ); ?>">
			<div class="tabs" role="tablist">
				<button class="tab" role="tab" data-ptab="el" aria-selected="true"><?php esc_html_e( 'Element', 'beerandomly' ); ?></button>
				<button class="tab" role="tab" data-ptab="add" aria-selected="false"><?php esc_html_e( 'Add', 'beerandomly' ); ?></button>
				<button class="tab" role="tab" data-ptab="site" aria-selected="false"><?php esc_html_e( 'Site', 'beerandomly' ); ?></button>
			</div>
			<div class="bld-pbody" id="bldPanel"></div>
		</aside>
	</div>
</div>

<dialog id="bldDlg" aria-labelledby="bldDlgTitle">
	<form class="dlg" id="bldDlgForm" novalidate>
		<div class="dlg-head"><h2 id="bldDlgTitle"><?php esc_html_e( 'Download your website', 'beerandomly' ); ?></h2></div>
		<p class="hint"><?php esc_html_e( 'Enter your email to download your .zip. We’ll occasionally send you free AI tips and new tools. You can unsubscribe anytime.', 'beerandomly' ); ?> <a href="<?php echo esc_url( br_page_url( 'privacy' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Privacy', 'beerandomly' ); ?></a></p>
		<label class="field"><span><?php esc_html_e( 'Email address', 'beerandomly' ); ?></span><input type="email" id="bldEmail" name="email" autocomplete="email" required placeholder="you@example.com"></label>
		<label class="bld-hp" aria-hidden="true">Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
		<p class="form-error" id="bldDlgErr" role="alert" hidden></p>
		<div class="dlg-actions"><button type="button" class="btn btn-quiet" id="bldDlgCancel"><?php esc_html_e( 'Cancel', 'beerandomly' ); ?></button><button type="submit" class="btn btn-primary" id="bldDlgGo"><?php esc_html_e( 'Download .zip', 'beerandomly' ); ?></button></div>
	</form>
</dialog>

<noscript><section class="card empty"><h2><?php esc_html_e( 'Turn on JavaScript', 'beerandomly' ); ?></h2><p><?php esc_html_e( 'The website builder runs in your browser and needs JavaScript.', 'beerandomly' ); ?></p></section></noscript>
</div>
<?php
get_footer();
