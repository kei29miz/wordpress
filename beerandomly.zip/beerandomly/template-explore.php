<?php
/**
 * Template Name: Explore
 *
 * @package beerandomly
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
br_topbar( get_the_title() ? get_the_title() : __( 'Explore', 'beerandomly' ) );
$all  = br_posts( 'all' );
$tags = get_tags( array( 'orderby' => 'count', 'order' => 'DESC', 'hide_empty' => true ) );
$tags = is_wp_error( $tags ) ? array() : $tags;
?>
<div class="stack"><section class="card"><div class="big-search"><label class="search"><?php echo br_icon( 'explore' ); // phpcs:ignore ?><input type="search" id="exQ" placeholder="<?php esc_attr_e( 'Search posts, thoughts and topics', 'beerandomly' ); ?>" aria-label="Search"></label></div></section>
<div id="exResults" hidden><section class="card feed"><div class="ex-head"><h3 id="exLabel"></h3><button class="btn btn-quiet" id="exClear"><?php esc_html_e( 'Clear', 'beerandomly' ); ?></button></div><div id="exNone" class="empty" hidden><h2><?php esc_html_e( 'No matches', 'beerandomly' ); ?></h2><p><?php esc_html_e( 'Try a different word or topic.', 'beerandomly' ); ?></p></div><div id="exList"><?php foreach ( $all as $p ) { br_acard( $p, array( 'search' => true ) ); } ?></div></section></div>
<div id="exDefault" class="stack"><section class="card surprise"><div class="ph-icon"><?php echo br_icon( 'random' ); // phpcs:ignore ?></div><div><b><?php esc_html_e( 'Feeling random?', 'beerandomly' ); ?></b><span><?php esc_html_e( 'Jump to any post on the blog.', 'beerandomly' ); ?></span></div><button class="btn btn-primary" data-random><?php esc_html_e( 'Surprise me', 'beerandomly' ); ?></button></section>
<?php if ( $tags ) : ?><section class="card"><div class="ex-head"><h2><?php esc_html_e( 'Topics', 'beerandomly' ); ?></h2><span class="count"><?php echo esc_html( br_plural( count( $tags ), 'topic', 'topics' ) ); ?></span></div><div class="topic-grid"><?php foreach ( $tags as $t ) { echo '<a class="topic-card" href="' . esc_url( get_tag_link( $t ) ) . '"><b>#' . esc_html( $t->name ) . '</b><small>' . esc_html( br_plural( $t->count, 'post', 'posts' ) ) . '</small></a>'; } ?></div></section><?php endif; ?>
<section class="card feed"><div class="ex-head"><h2><?php esc_html_e( 'Latest', 'beerandomly' ); ?></h2></div><?php foreach ( array_slice( $all, 0, 5 ) as $p ) { br_acard( $p ); } ?></section></div></div>
<?php get_footer();
