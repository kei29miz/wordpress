<?php
/**
 * Template Name: Thoughts
 *
 * @package beerandomly
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
br_topbar( get_the_title() ? get_the_title() : __( 'Thoughts', 'beerandomly' ) );
$posts = br_posts( 'thought' );
echo '<div class="stack">';
br_page_head( get_the_title() ? get_the_title() : __( 'Thoughts', 'beerandomly' ), br_plural( count( $posts ), 'thought', 'thoughts' ), 'thoughts', 'cv-lavender' );
echo '<div class="tgrid">';
foreach ( $posts as $p ) { br_tcard( $p ); }
echo '</div>';
if ( ! $posts ) { echo '<section class="card empty"><h2>' . esc_html__( 'No thoughts yet', 'beerandomly' ) . '</h2><p>' . esc_html__( 'Set a post’s Type to “Thought” in the editor.', 'beerandomly' ) . '</p></section>'; }
echo '</div>';
get_footer();
