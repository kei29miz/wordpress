<?php
/**
 * Template Name: Tools
 *
 * @package beerandomly
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$title = get_the_title() ? get_the_title() : __( 'Tools', 'beerandomly' );
br_topbar( $title );
echo '<div class="stack">';
br_page_head( $title, __( 'Free tools to help you build and earn', 'beerandomly' ), 'tools', 'cv-meadow' );
while ( have_posts() ) {
	the_post();
	if ( '' !== trim( get_the_content() ) ) {
		echo '<section class="card tools-intro"><div class="prose sz-s">';
		the_content();
		echo '</div></section>';
	}
}
?>
<section class="card feed">
	<h2 class="sr-only"><?php esc_html_e( 'All tools', 'beerandomly' ); ?></h2>
	<article class="tool-row">
		<div class="tool-ic cv cv-honey" aria-hidden="true"><?php echo br_icon( 'build' ); // phpcs:ignore ?></div>
		<div class="tool-txt">
			<h3><a href="<?php echo esc_url( br_page_url( 'builder' ) ); ?>"><?php esc_html_e( 'Free website builder', 'beerandomly' ); ?></a></h3>
			<p><?php esc_html_e( 'Pick a template, click anything to change it, then download your site as a .zip you can put online for free on Vercel or Cloudflare Pages. No sign-up, no code.', 'beerandomly' ); ?></p>
			<div class="tool-meta"><span><?php esc_html_e( 'Free', 'beerandomly' ); ?></span><span><?php esc_html_e( 'Works in your browser', 'beerandomly' ); ?></span></div>
		</div>
		<a class="btn btn-primary" href="<?php echo esc_url( br_page_url( 'builder' ) ); ?>"><?php esc_html_e( 'Open builder', 'beerandomly' ); ?></a>
	</article>
</section>
</div>
<?php
get_footer();
